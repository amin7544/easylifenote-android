package com.easylifenote.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [CompanyInfo::class, Memo::class, MemoItem::class, OvertimeSettings::class, OvertimeEntry::class, WordDocument::class],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun memoDao(): MemoDao
    abstract fun overtimeDao(): OvertimeDao
    abstract fun documentDao(): DocumentDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `memos` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`companyName` TEXT NOT NULL, `phone` TEXT NOT NULL, " +
                        "`address` TEXT NOT NULL, `memoDate` TEXT NOT NULL, " +
                        "`discount` REAL NOT NULL, `discountIsPercent` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `memo_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`memoId` INTEGER NOT NULL, `name` TEXT NOT NULL, " +
                        "`quantity` REAL NOT NULL, `rate` REAL NOT NULL, " +
                        "FOREIGN KEY(`memoId`) REFERENCES `memos`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_memo_items_memoId` ON `memo_items` (`memoId`)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `overtime_settings` (" +
                        "`id` INTEGER NOT NULL, `basicSalary` REAL NOT NULL, `hourlyRate` REAL NOT NULL, " +
                        "`daysPerMonth` INTEGER NOT NULL, `hoursPerDay` REAL NOT NULL, " +
                        "`dayMultiplier` REAL NOT NULL, `nightMultiplier` REAL NOT NULL, " +
                        "`regularMultiplier` REAL NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `overtime_entries` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `date` TEXT NOT NULL, " +
                        "`shift` TEXT NOT NULL, `hours` REAL NOT NULL, `hourlyRate` REAL NOT NULL, " +
                        "`multiplier` REAL NOT NULL, `amount` REAL NOT NULL)"
                )
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `documents` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, " +
                        "`html` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                )
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `memos` ADD COLUMN `memoType` TEXT NOT NULL DEFAULT 'BUY'")
            }
        }

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "easy_life_note.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { instance = it }
            }
    }
}
