package com.easylifenote.app.ui.excel

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.data.MemoItem
import com.easylifenote.app.data.MemoMath
import com.easylifenote.app.export.PdfExporter
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.common.ScreenHeader
import com.easylifenote.app.ui.common.WhiteCard
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.GreenA
import com.easylifenote.app.ui.theme.GreenB
import java.util.Calendar

private val Red = Color(0xFFD01C1C)

@Composable
fun MemoEditorScreen(onBack: () -> Unit, vm: MemoEditorViewModel = viewModel()) {
    val context = LocalContext.current
    var editing by remember { mutableStateOf<MemoItem?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showCalc by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    val doc = PdfExporter.buildDocument(vm.printData())
                    doc.writeTo(out)
                    doc.close()
                }
                toast("PDF saved successfully")
            } catch (e: Exception) {
                toast("Could not save PDF: ${e.message}")
            }
        }
    }

    fun pickDate() {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, y, m, d ->
                cal.set(y, m, d)
                vm.date = MemoMath.formatDate(cal)
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    GradientScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            ScreenHeader(if (vm.memoType == "SALES") "Sales Memo" else "Purchase Memo", onBack)

            if (vm.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White)
                }
            } else {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // ---- Company ----
                    WhiteCard {
                        Text("Company Details", fontWeight = FontWeight.ExtraBold, color = BlueDeep, fontSize = 17.sp)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            vm.companyName, { vm.companyName = it },
                            label = { Text("Company name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            vm.phone, { vm.phone = it },
                            label = { Text("Phone number") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            vm.address, { vm.address = it },
                            label = { Text("Address") }, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            vm.date, {}, readOnly = true,
                            label = { Text("Date") }, singleLine = true,
                            trailingIcon = {
                                IconButton(onClick = { pickDate() }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Pick date", tint = BlueMid)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // ---- Items table ----
                    WhiteCard {
                        Text("Items", fontWeight = FontWeight.ExtraBold, color = BlueDeep, fontSize = 17.sp)
                        Spacer(Modifier.height(6.dp))
                        TableHeader()
                        if (vm.items.isEmpty()) {
                            Text(
                                "No items yet. Tap \"Add Item\".",
                                color = Color.DarkGray, fontSize = 13.sp,
                                modifier = Modifier.fillMaxWidth().padding(14.dp), textAlign = TextAlign.Center
                            )
                        }
                        vm.items.forEachIndexed { index, item ->
                            ItemRow(index + 1, item) { editing = item }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { showAdd = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = GreenB)
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                                Text(" Add Item")
                            }
                            OutlinedButton(onClick = { showCalc = true }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Calculate, null, modifier = Modifier.size(18.dp))
                                Text(" Calculator")
                            }
                        }
                    }

                    // ---- Discount + totals ----
                    WhiteCard {
                        Text("Discount", fontWeight = FontWeight.ExtraBold, color = BlueDeep, fontSize = 17.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                vm.discountText,
                                { if (MemoMath.isDecimalInput(it)) vm.discountText = it },
                                label = { Text("Discount") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            ToggleButton("Amount", !vm.discountIsPercent) { vm.discountIsPercent = false }
                            ToggleButton("%", vm.discountIsPercent) { vm.discountIsPercent = true }
                        }
                        Spacer(Modifier.height(10.dp))
                        SummaryRow("Subtotal", MemoMath.fmt(vm.subtotal))
                        SummaryRow("Discount", "- " + MemoMath.fmt(vm.discountAmount))
                        Row(
                            Modifier.fillMaxWidth().padding(top = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Grand Total", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = BlueDeep)
                            Text(MemoMath.fmt(vm.grandTotal), fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = Red)
                        }
                    }

                    // ---- Actions ----
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton("Save", GreenA, Modifier.weight(1f)) {
                            vm.save { err -> toast(err ?: "Memo saved") }
                        }
                        ActionButton("Print", BlueMid, Modifier.weight(1f)) {
                            if (vm.items.isEmpty()) toast("Add at least one item first.")
                            else PdfExporter.print(context, vm.printData(), "Memo ${vm.date}")
                        }
                        ActionButton("Export PDF", Red, Modifier.weight(1f)) {
                            if (vm.items.isEmpty()) toast("Add at least one item first.")
                            else {
                                val safe = vm.companyName.trim().replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
                                exportLauncher.launch("Memo_${safe.ifBlank { "Easy_Life_Note" }}_${vm.date.replace(' ', '_')}.pdf")
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }

    if (showAdd) {
        ItemDialog(
            initial = null,
            onDismiss = { showAdd = false },
            onSave = { n, q, r -> vm.addItem(n, q, r); showAdd = false },
            onDelete = null
        )
    }
    editing?.let { item ->
        ItemDialog(
            initial = item,
            onDismiss = { editing = null },
            onSave = { n, q, r -> vm.updateItem(item.id, n, q, r); editing = null },
            onDelete = { vm.deleteItem(item.id); editing = null }
        )
    }
    if (showCalc) CalculatorDialog { showCalc = false }
}

// ---------------------------------------------------------------- table

@Composable
private fun TableHeader() {
    Row(
        Modifier.fillMaxWidth().background(BlueMid).padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderCell("SL", 0.10f, TextAlign.Start)
        HeaderCell("Item", 0.36f, TextAlign.Start)
        HeaderCell("Qty", 0.14f, TextAlign.End)
        HeaderCell("Rate", 0.17f, TextAlign.End)
        HeaderCell("Total", 0.23f, TextAlign.End)
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.HeaderCell(text: String, weight: Float, align: TextAlign) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = align, modifier = Modifier.weight(weight))
}

@Composable
private fun ItemRow(sl: Int, item: MemoItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (sl % 2 == 0) Color(0xFFE6EEFF) else Color.White)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$sl", fontSize = 12.sp, modifier = Modifier.weight(0.10f))
        Text(item.name, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(0.36f))
        Text(MemoMath.fmt(item.quantity), fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.14f))
        Text(MemoMath.fmt(item.rate), fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.17f))
        Text(
            MemoMath.fmt(MemoMath.lineTotal(item.quantity, item.rate)),
            fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(0.23f)
        )
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 15.sp, color = Color.DarkGray)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ToggleButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) BlueMid else Color(0xFFD5E0F7),
            contentColor = if (selected) Color.White else BlueDeep
        )
    ) { Text(text, fontSize = 13.sp) }
}

@Composable
private fun ActionButton(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        contentPadding = PaddingValues(horizontal = 4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1) }
}

// ---------------------------------------------------------------- dialogs

@Composable
private fun ItemDialog(
    initial: MemoItem?,
    onDismiss: () -> Unit,
    onSave: (String, Double, Double) -> Unit,
    onDelete: (() -> Unit)?
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var qty by remember { mutableStateOf(initial?.let { MemoMath.plain(it.quantity) } ?: "") }
    var rate by remember { mutableStateOf(initial?.let { MemoMath.plain(it.rate) } ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val q = qty.toDoubleOrNull() ?: 0.0
    val r = rate.toDoubleOrNull() ?: 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Item" else "Edit Item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Item name") }, singleLine = true)
                OutlinedTextField(
                    qty, { if (MemoMath.isDecimalInput(it)) qty = it },
                    label = { Text("Quantity") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    rate, { if (MemoMath.isDecimalInput(it)) rate = it },
                    label = { Text("Unit price") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Text("Total: " + MemoMath.fmt(MemoMath.lineTotal(q, r)), fontWeight = FontWeight.Bold, color = BlueDeep)
                error?.let { Text(it, color = Red, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val qv = qty.toDoubleOrNull()
                val rv = rate.toDoubleOrNull()
                when {
                    name.isBlank() -> error = "Enter the item name."
                    qv == null || qv <= 0.0 -> error = "Enter a quantity greater than 0."
                    rv == null || rv < 0.0 -> error = "Enter the unit price."
                    else -> onSave(name.trim(), qv, rv)
                }
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Delete", color = Red) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

/** Simple calculator: + - × ÷ on two numbers. */
@Composable
private fun CalculatorDialog(onDismiss: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var last by remember { mutableStateOf<Double?>(null) }

    fun calc(op: Char) {
        val x = a.toDoubleOrNull()
        val y = b.toDoubleOrNull()
        if (x == null || y == null) {
            result = "Enter both numbers."
            last = null
            return
        }
        if (op == '÷' && y == 0.0) {
            result = "Cannot divide by zero."
            last = null
            return
        }
        val r = when (op) {
            '+' -> x + y
            '−' -> x - y
            '×' -> x * y
            else -> x / y
        }
        last = r
        result = "${MemoMath.calcFmt(x)} $op ${MemoMath.calcFmt(y)} = ${MemoMath.calcFmt(r)}"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Calculator") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    a, { if (MemoMath.isDecimalInput(it)) a = it },
                    label = { Text("First number") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    b, { if (MemoMath.isDecimalInput(it)) b = it },
                    label = { Text("Second number") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CalcOp("+", GreenA, Modifier.weight(1f)) { calc('+') }
                    CalcOp("−", BlueMid, Modifier.weight(1f)) { calc('−') }
                    CalcOp("×", GreenB, Modifier.weight(1f)) { calc('×') }
                    CalcOp("÷", BlueDeep, Modifier.weight(1f)) { calc('÷') }
                }
                if (result.isNotEmpty()) {
                    Text(result, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (last == null) Red else BlueDeep)
                }
                last?.let { value ->
                    TextButton(onClick = { a = MemoMath.calcFmt(value); b = ""; result = ""; last = null }) {
                        Text("Use result as first number")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun CalcOp(symbol: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) { Text(symbol, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
}
