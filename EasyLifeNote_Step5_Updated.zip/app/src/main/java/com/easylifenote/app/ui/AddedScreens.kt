package com.easylifenote.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalUriHandler
import com.easylifenote.app.ui.theme.*
import java.text.NumberFormat
import java.util.Locale
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Navy = Color(0xFF092A9B)
private val Sky = Color(0xFFEAF4FF)
private fun money(v: Double) = "৳ " + NumberFormat.getNumberInstance(Locale.US).apply { minimumFractionDigits=2; maximumFractionDigits=2 }.format(v)

@Composable
private fun PageFrame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A36B8), Color(0xFFEFF6FF), Color.White))).padding(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom=12.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint=Color.White) }
            Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.ExtraBold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(12.dp), content=content)
    }
}

@Composable
fun SalaryCalculatorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var savedRecord by remember { mutableStateOf(false) }
    var employee by remember { mutableStateOf("") }
    var basic by remember { mutableStateOf("") }
    var rateMode by remember { mutableStateOf("Auto") }
    var customRate by remember { mutableStateOf("") }
    var otHours by remember { mutableStateOf("") }
    var shift by remember { mutableStateOf("Day") }
    var daysPerMonth by remember { mutableStateOf("30") }
    var hoursPerDay by remember { mutableStateOf("8") }
    var calculated by remember { mutableStateOf(false) }
    val salary = basic.toDoubleOrNull() ?: 0.0
    // Auto rate is the base hourly rate: monthly basic salary / (30 days × 8 hours).
    val divisor = (daysPerMonth.toDoubleOrNull() ?: 0.0) * (hoursPerDay.toDoubleOrNull() ?: 0.0)
    val autoRate = if (salary > 0 && divisor > 0) salary / divisor else 0.0
    val rate = if (rateMode == "Auto") autoRate else (customRate.toDoubleOrNull() ?: 0.0)
    val hours = otHours.toDoubleOrNull() ?: 0.0
    val otPay = rate * hours
    PageFrame("Salary Calculator", onBack) {
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(employee,{employee=it},label={Text("Employee Name")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(basic,{basic=it;calculated=false},label={Text("Basic Salary (৳)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
                Text("Overtime Rate",fontWeight=FontWeight.Bold,color=Navy)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    listOf("Auto","Custom").forEach { mode -> Row(Modifier.weight(1f).clickable { rateMode=mode;calculated=false },verticalAlignment=Alignment.CenterVertically) { RadioButton(rateMode==mode,{rateMode=mode;calculated=false});Text(mode) } }
                }
                if(rateMode=="Custom") OutlinedTextField(customRate,{customRate=it;calculated=false},label={Text("Enter OT Rate per Hour (৳)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
                else Text("Auto OT rate: ${money(autoRate)} per hour",color=BlueDeep,fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(daysPerMonth,{daysPerMonth=it},label={Text("Days / Month")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.weight(1f))
                    OutlinedTextField(hoursPerDay,{hoursPerDay=it},label={Text("Hours / Day")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.weight(1f))
                }
                Text("Auto formula: Basic Salary ÷ (working days × hours per day)",fontSize=12.sp,color=Color.Gray)
                OutlinedTextField(otHours,{otHours=it;calculated=false},label={Text("Total Overtime Hours")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
                Text("Shift Type",fontWeight=FontWeight.Bold,color=Navy)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Day","Night","Regular").forEach { FilterChip(selected=shift==it,onClick={shift=it},label={Text(it)}) } }
                Button(onClick={calculated=true;savedRecord=false},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Calculate,null);Text("  Calculate") }
            }
        }
        if(calculated) Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE8FBEA))) {
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                Text("Calculation Result",fontWeight=FontWeight.ExtraBold,color=GreenB,fontSize=18.sp)
                ResultLine("Employee",employee.ifBlank { "Not entered" })
                ResultLine("Shift",shift)
                ResultLine("OT Rate",money(rate))
                ResultLine("Total OT Hours","${hours} hours")
                ResultLine("Basic Salary",money(salary))
                ResultLine("Overtime Pay",money(otPay))
                Divider()
                ResultLine("Total Salary",money(salary+otPay),true)
                Button(onClick={
                    val prefs=context.getSharedPreferences("easylifenote_salary",android.content.Context.MODE_PRIVATE)
                    val arr=try { JSONArray(prefs.getString("records","[]") ?: "[]") } catch (_:Exception) { JSONArray() }
                    arr.put(JSONObject().put("employee",employee.ifBlank { "Unnamed" }).put("basic",salary).put("hours",hours).put("rate",rate).put("ot",otPay).put("total",salary+otPay).put("month",LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))))
                    prefs.edit().putString("records",arr.toString()).apply()
                    savedRecord=true
                },modifier=Modifier.fillMaxWidth(),enabled=!savedRecord) { Text(if(savedRecord) "Saved" else "Save Salary Record") }
            }
        }
    }
}

@Composable
private fun ResultLine(label:String,value:String,emphasis:Boolean=false) {
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(label,fontWeight=if(emphasis) FontWeight.Bold else FontWeight.Normal);Text(value,fontWeight=FontWeight.Bold,color=if(emphasis) GreenB else Navy) }
}

@Composable
fun SalaryReportScreen(onBack: () -> Unit) {
    val context=LocalContext.current
    var month by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))) }
    var records by remember { mutableStateOf(listOf<JSONObject>()) }
    LaunchedEffect(Unit) {
        val raw=context.getSharedPreferences("easylifenote_salary",android.content.Context.MODE_PRIVATE).getString("records","[]") ?: "[]"
        records=try { val a=JSONArray(raw); (0 until a.length()).map { a.getJSONObject(it) } } catch (_:Exception) { emptyList() }
    }
    val filtered=records.filter { it.optString("month")==month }
    val basic=filtered.sumOf { it.optDouble("basic") };val ot=filtered.sumOf { it.optDouble("ot") };val hours=filtered.sumOf { it.optDouble("hours") }
    PageFrame("Salary Report",onBack) {
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Monthly Salary Summary",fontWeight=FontWeight.Bold,color=Navy,fontSize=18.sp)
                OutlinedTextField(month,{month=it},label={Text("Month (YYYY-MM)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                ResultLine("Total Basic Salary",money(basic));ResultLine("Total OT Amount",money(ot));ResultLine("Total OT Hours","$hours hours");ResultLine("Total Employees",filtered.map { it.optString("employee") }.distinct().size.toString())
                Divider();ResultLine("Grand Total",money(basic+ot),true)
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(12.dp)) {
                Text("Employee-wise Report",fontWeight=FontWeight.Bold,color=Navy,fontSize=18.sp)
                if(filtered.isEmpty()) Text("No saved salary records for this month. Open Salary Calculator, calculate salary and tap Save Salary Record.",Modifier.padding(10.dp),color=Color.Gray)
                filtered.forEach { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(item.optString("employee"),fontWeight=FontWeight.Bold);Text("OT: ${item.optDouble("hours")} hours",fontSize=12.sp,color=Color.Gray) }
                        Text(money(item.optDouble("total")),fontWeight=FontWeight.Bold,color=Navy)
                    };Divider()
                }
            }
        }
    }
}

private data class Staff(val id:String,val name:String,val shift:String,val time:String,val days:String)

@Composable
fun ShiftSchedulerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var month by remember { mutableStateOf("November 2026") }
    var selected by remember { mutableStateOf("Day 7 Days") }
    var staff by remember {
        mutableStateOf(run {
            val saved = context.getSharedPreferences("easylifenote_shift", android.content.Context.MODE_PRIVATE).getString("staff", "[]") ?: "[]"
            try {
                val arr = JSONArray(saved)
                (0 until arr.length()).map { i -> arr.getJSONObject(i).let { Staff(it.optString("id"),it.optString("name"),it.optString("shift"),it.optString("time"),it.optString("days")) } }
            } catch (_: Exception) { emptyList() }
        })
    }
    LaunchedEffect(staff) {
        val arr = JSONArray()
        staff.forEach { p -> arr.put(JSONObject().put("id",p.id).put("name",p.name).put("shift",p.shift).put("time",p.time).put("days",p.days)) }
        context.getSharedPreferences("easylifenote_shift", android.content.Context.MODE_PRIVATE).edit().putString("staff",arr.toString()).apply()
    }
    var showAdd by remember { mutableStateOf(false) }
    var editStaff by remember { mutableStateOf<Staff?>(null) }
    var filter by remember { mutableStateOf("All") }
    val visible = staff.filter { filter=="All" || it.shift==filter }
    PageFrame("Shift Scheduler",onBack) {
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(month,{month=it},label={Text("Select Month")},singleLine=true,modifier=Modifier.fillMaxWidth())
                Text("Shift / Day Selection",fontWeight=FontWeight.Bold,color=Navy)
                listOf("Day 7 Days","Day 30 Days","Regular","Night").chunked(2).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEach { item -> FilterChip(selected==item,onClick={selected=item},label={Text(item)},modifier=Modifier.weight(1f)) } } }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("All","Day","Night","Regular").forEach { FilterChip(filter==it,{filter=it},label={Text(it)}) } }
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(8.dp).horizontalScroll(rememberScrollState())) {
                Row(Modifier.width(690.dp).background(Navy).padding(7.dp)) {
                    listOf("#","ID","Employee Name","Shift Type","Shift Time","Days","Status").forEachIndexed { i, label ->
                        Text(label,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp,
                            modifier=Modifier.width(listOf(32.dp,64.dp,132.dp,88.dp,112.dp,82.dp,72.dp)[i]))
                    }
                }
                if(visible.isEmpty()) Text("No employees added. Tap Add Employee to create the schedule.",Modifier.padding(14.dp),color=Color.Gray)
                visible.forEachIndexed { index, person ->
                    Row(Modifier.width(690.dp).clickable { editStaff=person }.padding(vertical=10.dp,horizontal=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        listOf("${index+1}",person.id,person.name,person.shift,person.time,person.days,"Active").forEachIndexed { i, value ->
                            Text(value,fontSize=11.sp,color=if(i==6) Color(0xFF168A50) else Color.DarkGray,
                                fontWeight=if(i==6) FontWeight.Bold else FontWeight.Normal,
                                modifier=Modifier.width(listOf(32.dp,64.dp,132.dp,88.dp,112.dp,82.dp,72.dp)[i]))
                        }
                    }
                    Divider()
                }
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(onClick={showAdd=true},modifier=Modifier.weight(1f)) { Icon(Icons.Default.PersonAdd,null);Text(" Add Employee") }
            OutlinedButton(onClick={filter="All"},modifier=Modifier.weight(1f)) { Text("Show All") }
        }
        Text("Employee ID is required so people with the same name can be identified separately.",fontSize=12.sp,color=Color.DarkGray)
    }
    if(showAdd || editStaff!=null) StaffDialog(editStaff,selected,{showAdd=false;editStaff=null},{ item ->
        staff=if(editStaff==null) staff.filterNot { it.id.equals(item.id,true) }+item else staff.map { if(it.id==editStaff!!.id) item else it }
        showAdd=false;editStaff=null
    },{ id -> staff=staff.filterNot { it.id==id };editStaff=null })
}

@Composable
private fun StaffDialog(existing:Staff?,defaultShift:String,onDismiss:()->Unit,onSave:(Staff)->Unit,onDelete:(String)->Unit) {
    var id by remember { mutableStateOf(existing?.id ?: "") };var name by remember { mutableStateOf(existing?.name ?: "") }
    var shift by remember { mutableStateOf(existing?.shift ?: defaultShift.substringBefore(" ")) };var days by remember { mutableStateOf(existing?.days ?: if(defaultShift.contains("7")) "7 Days" else if(defaultShift.contains("30")) "30 Days" else "Regular") }
    var time by remember { mutableStateOf(existing?.time ?: "8 AM - 4 PM") };var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null) "Add Employee" else "Edit Employee")},text={
        Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(id,{id=it},label={Text("Employee ID (required)")},singleLine=true)
            OutlinedTextField(name,{name=it},label={Text("Employee Name")},singleLine=true)
            Text("Shift Type")
            Row { listOf("Day","Night","Regular").forEach { FilterChip(shift==it,{shift=it},label={Text(it)}) } }
            Text("Duration")
            Row { listOf("7 Days","30 Days","Regular").forEach { FilterChip(days==it,{days=it},label={Text(it)}) } }
            OutlinedTextField(time,{time=it},label={Text("Shift Time")},singleLine=true)
            if(error.isNotBlank()) Text(error,color=Color.Red)
        }
    },confirmButton={TextButton(onClick={if(id.isBlank()||name.isBlank()) error="Enter both Employee ID and Name." else onSave(Staff(id.trim(),name.trim(),shift,time.trim(),days))}){Text("Save")} },dismissButton={Row { if(existing!=null) TextButton(onClick={onDelete(existing.id)}){Text("Delete",color=Color.Red)};TextButton(onClick=onDismiss){Text("Cancel")} }})
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val uriHandler= LocalUriHandler.current
    PageFrame("About EasyLifeNote",onBack) {
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.fillMaxWidth().padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(Icons.Default.Description,null,tint=BlueMid,modifier=Modifier.size(56.dp))
            Text("EasyLifeNote",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
            Text("Smart Excel Tools for Your Daily Life",color=BlueMid)
            Text("Version 1.0.0",fontWeight=FontWeight.Bold)
        } }
        InfoCard("About This App","EasyLifeNote helps you manage salary calculations, overtime, work shifts, memos, documents and everyday records in one place.")
        InfoCard("Key Features","• Salary Calculator\n• Overtime Calculator\n• Salary Report\n• Shift Scheduler\n• Buy Items and Sales Items memos\n• Word editor, PDF and print tools")
        InfoCard("Developed By","MD. AL-AMIN\nNetrokona, Dhaka, Bangladesh")
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Contact & Support",fontWeight=FontWeight.Bold,color=Navy,fontSize=18.sp)
            Text("Email: Alaminkazla21@gmail.com")
            Button(onClick={uriHandler.openUri("mailto:Alaminkazla21@gmail.com")},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Email,null);Text("  Email Support") }
            Button(onClick={uriHandler.openUri("https://wa.me/8801932037601")},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF159447))) { Icon(Icons.Default.Chat,null);Text("  WhatsApp Support") }
        } }
        InfoCard("Privacy & Terms","Your records are stored on your device unless you choose to share or export them. Use the app responsibly and keep backups of important documents.")
        Text("Made with ♥ by MD. AL-AMIN",Modifier.fillMaxWidth().padding(12.dp),color=Navy,fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun InfoCard(title:String,body:String) { Card(colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(16.dp)) { Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold,color=Navy);Spacer(Modifier.height(6.dp));Text(body,color=Color.DarkGray) } } }
