package com.easylifenote.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.FloatingActionButton
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.easylifenote.app.ui.excel.ExcelListScreen
import com.easylifenote.app.ui.excel.MemoEditorScreen
import com.easylifenote.app.ui.overtime.OvertimeScreen
import com.easylifenote.app.ui.word.WordEditorScreen
import com.easylifenote.app.ui.word.WordListScreen
import com.easylifenote.app.ui.home.HomeScreen
import com.easylifenote.app.ui.SalaryCalculatorScreen
import com.easylifenote.app.ui.SalaryReportScreen
import com.easylifenote.app.ui.ShiftSchedulerScreen
import com.easylifenote.app.ui.AboutScreen

object Routes {
    const val HOME = "home"
    const val CLOUD = "cloud"
    const val SETTINGS = "settings"
    const val EXCEL = "excel"
    const val EXCEL_EDIT = "excel_edit"
    const val WORD = "word"
    const val WORD_EDIT = "word_edit"
    const val OVERTIME = "overtime"
    const val REMINDER = "reminder"
    const val PRINT = "print"
    const val PDF = "pdf"
    const val ABOUT = "about"
    const val SALARY = "salary"
    const val SALARY_REPORT = "salary_report"
    const val SHIFT_SCHEDULER = "shift_scheduler"
}

/** Which build step will deliver each screen (shown on the temporary screens). */
private val stepFor = mapOf(
    Routes.REMINDER to ("Reminder" to 4),
    Routes.PRINT to ("Print" to 6),
    Routes.PDF to ("Export PDF" to 6),
    Routes.CLOUD to ("Google Drive Cloud" to 7),

    Routes.SETTINGS to ("Settings" to 8)
)

@Composable
fun AppRoot() {
    val uriHandler = LocalUriHandler.current
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val bottomRoutes = listOf(Routes.HOME, Routes.CLOUD, Routes.SETTINGS)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { uriHandler.openUri("https://wa.me/8801932037601") }) {
                Icon(Icons.Default.Chat, contentDescription = "WhatsApp Support")
            }
        },
        bottomBar = {
            if (route in bottomRoutes) {
                NavigationBar {
                    BottomItem(route == Routes.HOME, "Home", Icons.Default.Home) { goTab(nav, Routes.HOME) }
                    BottomItem(route == Routes.CLOUD, "Cloud", Icons.Default.Cloud) { goTab(nav, Routes.CLOUD) }
                    BottomItem(route == Routes.SETTINGS, "Settings", Icons.Default.Settings) { goTab(nav, Routes.SETTINGS) }
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) { HomeScreen(onOpen = { nav.navigate(it) }) }
            composable(Routes.OVERTIME) { OvertimeScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.SALARY) { SalaryCalculatorScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.SALARY_REPORT) { SalaryReportScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.SHIFT_SCHEDULER) { ShiftSchedulerScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.ABOUT) { AboutScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.WORD) {
                WordListScreen(
                    onBack = { nav.popBackStack() },
                    onOpen = { id -> nav.navigate("${Routes.WORD_EDIT}/$id") }
                )
            }
            composable(
                "${Routes.WORD_EDIT}/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) {
                WordEditorScreen(onBack = { nav.popBackStack() })
            }
            composable(Routes.EXCEL) {
                ExcelListScreen(
                    onBack = { nav.popBackStack() },
                    onOpen = { id, type -> nav.navigate("${Routes.EXCEL_EDIT}/$id/$type") }
                )
            }
            composable(
                "${Routes.EXCEL_EDIT}/{id}/{type}",
                arguments = listOf(
                    navArgument("id") { type = NavType.LongType },
                    navArgument("type") { type = NavType.StringType; defaultValue = "BUY" }
                )
            ) {
                MemoEditorScreen(onBack = { nav.popBackStack() })
            }
            stepFor.forEach { (r, info) ->
                composable(r) {
                    ComingSoonScreen(info.first, info.second, showBack = r !in bottomRoutes) { nav.popBackStack() }
                }
            }
        }
    }
}

private fun goTab(nav: androidx.navigation.NavController, route: String) {
    nav.navigate(route) {
        popUpTo(Routes.HOME) { inclusive = false }
        launchSingleTop = true
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.BottomItem(
    selected: Boolean, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit
) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}

/** Temporary screen that is replaced step by step. */
@Composable
fun ComingSoonScreen(title: String, step: Int, showBack: Boolean, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        if (showBack) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        }
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("This screen is built in Step $step.", modifier = Modifier.padding(top = 8.dp))
        }
    }
}
