package com.easylifenote.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Salary information (one row, id = 1). */
@Entity(tableName = "overtime_settings")
data class OvertimeSettings(
    @PrimaryKey val id: Int = 1,
    val basicSalary: Double = 0.0,
    val hourlyRate: Double = 0.0,
    val daysPerMonth: Int = 30,
    val hoursPerDay: Double = 8.0,
    val dayMultiplier: Double = 1.5,
    val nightMultiplier: Double = 2.0,
    val regularMultiplier: Double = 1.0
)

/** One overtime record. Rate and multiplier are stored so old records never change. */
@Entity(tableName = "overtime_entries")
data class OvertimeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,          // ISO date, e.g. 2026-11-17
    val shift: String,         // Shift.name
    val hours: Double,
    val hourlyRate: Double,
    val multiplier: Double,
    val amount: Double
)

enum class Shift(val label: String) {
    DAY("Day"),
    NIGHT("Night"),
    REGULAR("Regular");

    companion object {
        fun from(name: String): Shift = values().firstOrNull { it.name == name } ?: REGULAR
    }
}
