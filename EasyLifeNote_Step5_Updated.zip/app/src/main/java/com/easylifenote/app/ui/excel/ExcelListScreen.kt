package com.easylifenote.app.ui.excel

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.data.MemoMath
import com.easylifenote.app.data.MemoWithItems
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.common.ScreenHeader
import com.easylifenote.app.ui.common.WhiteCard
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.Gold

@Composable
fun ExcelListScreen(
    onBack: () -> Unit,
    onOpen: (Long, String) -> Unit,
    vm: ExcelListViewModel = viewModel()
) {
    val memos by vm.memos.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<MemoWithItems?>(null) }
    var showRecords by remember { mutableStateOf(false) }

    GradientScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            ScreenHeader("Excel & Business Tools", onBack)
            if (!showRecords) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Sales Memo", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    WhiteCard(Modifier.fillMaxWidth().clickable { onOpen(0L, "BUY") }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ShoppingCart, null, tint = BlueMid, modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Buy Items", color = BlueDeep, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                                Text("Purchase Memo", color = Color.DarkGray, fontSize = 13.sp)
                            }
                            Button(onClick = { onOpen(0L, "BUY") }, colors = ButtonDefaults.buttonColors(containerColor = BlueMid)) {
                                Text("New Memo")
                            }
                        }
                    }
                    WhiteCard(Modifier.fillMaxWidth().clickable { onOpen(0L, "SALES") }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Store, null, tint = Color(0xFF168A50), modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Sales Items", color = BlueDeep, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                                Text("Sales Memo", color = Color.DarkGray, fontSize = 13.sp)
                            }
                            Button(onClick = { onOpen(0L, "SALES") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168A50))) {
                                Text("New Memo")
                            }
                        }
                    }
                    WhiteCard(Modifier.fillMaxWidth().clickable { showRecords = true }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, null, tint = Gold, modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("My Records", color = BlueDeep, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                                Text("View and manage saved memos", color = Color.DarkGray, fontSize = 13.sp)
                            }
                            Button(onClick = { showRecords = true }, colors = ButtonDefaults.buttonColors(containerColor = BlueDeep)) {
                                Text("Open")
                            }
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("My Records", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showRecords = false }) { Text("Back to Excel Home", color = Color.White) }
                }
                when {
                    memos == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White)
                    }
                    memos!!.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No saved memos yet.", color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center)
                    }
                    else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(memos!!, key = { it.memo.id }) { m ->
                            MemoCard(m, onClick = { onOpen(m.memo.id, m.memo.memoType) }, onDelete = { toDelete = m })
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete memo?") },
            text = { Text("This memo and all its rows will be deleted permanently.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(m.memo.id); toDelete = null }) {
                    Text("Delete", color = Color(0xFFD01C1C))
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MemoCard(m: MemoWithItems, onClick: () -> Unit, onDelete: () -> Unit) {
    val total = MemoMath.grandTotal(m.items, m.memo.discount, m.memo.discountIsPercent)
    WhiteCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (m.memo.memoType == "SALES") "Sales Memo" else "Purchase Memo",
                    fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = BlueDeep)
                Text(m.memo.companyName.ifBlank { "Untitled memo" }, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${m.memo.memoDate}  •  ${m.items.size} item(s)", fontSize = 12.sp, color = Color.DarkGray)
                Text("Total: ${MemoMath.fmt(total)}", fontWeight = FontWeight.Bold, color = Color(0xFFD01C1C), fontSize = 16.sp)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete memo", tint = BlueMid)
            }
        }
    }
}
