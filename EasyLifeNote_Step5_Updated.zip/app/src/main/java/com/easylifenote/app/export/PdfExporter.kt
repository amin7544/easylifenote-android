package com.easylifenote.app.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.easylifenote.app.data.MemoMath
import java.io.FileOutputStream

data class PrintRow(val name: String, val qty: Double, val rate: Double, val total: Double)

data class MemoPrintData(
    val companyName: String,
    val phone: String,
    val address: String,
    val date: String,
    val rows: List<PrintRow>,
    val subtotal: Double,
    val discountLabel: String,
    val discountAmount: Double,
    val grandTotal: Double,
    val memoTitle: String = "MEMO"
)

object PdfExporter {
    internal const val W = 595      // A4 width in points
    internal const val H = 842      // A4 height in points
    internal const val M = 36f      // page margin
    internal val BLUE = Color.rgb(27, 85, 224)
    internal val LIGHT = Color.rgb(234, 241, 255)
    internal val RED = Color.rgb(208, 28, 28)

    internal fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            this.color = color
            textAlign = align
        }

    internal fun fill(color: Int) = Paint().apply { this.color = color; style = Paint.Style.FILL }

    fun buildDocument(d: MemoPrintData): PdfDocument {
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var canvas = page.canvas
        drawFooter(canvas, pageNo)
        var y = drawHeader(canvas, d)
        y = drawTableHeader(canvas, y)

        for ((index, row) in d.rows.withIndex()) {
            if (y > H - 80f) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
                canvas = page.canvas
                drawFooter(canvas, pageNo)
                y = drawTableHeader(canvas, M + 10f)
            }
            y = drawRow(canvas, y, index + 1, row)
        }

        if (y > H - 170f) {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            canvas = page.canvas
            drawFooter(canvas, pageNo)
            y = M + 10f
        }
        drawSummary(canvas, y + 14f, d)
        doc.finishPage(page)
        return doc
    }

    private fun drawHeader(c: Canvas, d: MemoPrintData): Float {
        c.drawRect(0f, 0f, W.toFloat(), 96f, fill(BLUE))
        c.drawText(ellipsize(d.companyName.ifBlank { "Memo" }, paint(20f, true), 340f), M, 42f, paint(20f, true, Color.WHITE))
        if (d.phone.isNotBlank()) c.drawText("Phone: ${d.phone}", M, 62f, paint(11f, false, Color.WHITE))
        if (d.address.isNotBlank()) c.drawText(ellipsize(d.address, paint(11f), 340f), M, 78f, paint(11f, false, Color.WHITE))
        c.drawText(d.memoTitle.uppercase(), W - M, 42f, paint(20f, true, Color.WHITE, Paint.Align.RIGHT))
        c.drawText("Date: ${d.date}", W - M, 62f, paint(11f, false, Color.WHITE, Paint.Align.RIGHT))
        return 116f
    }

    private fun drawTableHeader(c: Canvas, y: Float): Float {
        c.drawRect(M, y, W - M, y + 24f, fill(BLUE))
        val p = paint(11f, true, Color.WHITE)
        val r = paint(11f, true, Color.WHITE, Paint.Align.RIGHT)
        c.drawText("SL", M + 6f, y + 16f, p)
        c.drawText("Item Name", M + 40f, y + 16f, p)
        c.drawText("Qty", 380f, y + 16f, r)
        c.drawText("Rate", 465f, y + 16f, r)
        c.drawText("Total", W - M - 6f, y + 16f, r)
        return y + 24f
    }

    private fun drawRow(c: Canvas, y: Float, sl: Int, row: PrintRow): Float {
        if (sl % 2 == 0) c.drawRect(M, y, W - M, y + 22f, fill(LIGHT))
        val p = paint(11f)
        val r = paint(11f, false, Color.BLACK, Paint.Align.RIGHT)
        c.drawText(sl.toString(), M + 6f, y + 15f, p)
        c.drawText(ellipsize(row.name, p, 255f), M + 40f, y + 15f, p)
        c.drawText(MemoMath.fmt(row.qty), 380f, y + 15f, r)
        c.drawText(MemoMath.fmt(row.rate), 465f, y + 15f, r)
        c.drawText(MemoMath.fmt(row.total), W - M - 6f, y + 15f, r)
        c.drawLine(M, y + 22f, W - M, y + 22f, fill(Color.LTGRAY))
        return y + 22f
    }

    private fun drawSummary(c: Canvas, y: Float, d: MemoPrintData) {
        val label = paint(12f, true)
        val value = paint(12f, false, Color.BLACK, Paint.Align.RIGHT)
        val x = 340f
        val right = W - M - 6f
        c.drawText("Subtotal", x, y + 14f, label)
        c.drawText(MemoMath.fmt(d.subtotal), right, y + 14f, value)
        c.drawText(d.discountLabel, x, y + 36f, label)
        c.drawText("- " + MemoMath.fmt(d.discountAmount), right, y + 36f, value)
        c.drawRect(x - 8f, y + 46f, W - M, y + 78f, fill(BLUE))
        c.drawText("Grand Total", x, y + 68f, paint(14f, true, Color.WHITE))
        c.drawText(MemoMath.fmt(d.grandTotal), right, y + 68f, paint(15f, true, Color.WHITE, Paint.Align.RIGHT))
    }

    internal fun drawFooter(c: Canvas, pageNo: Int) {
        c.drawText("Generated by Easy Life Note  |  Page $pageNo", W / 2f, H - 20f, paint(9f, false, Color.GRAY, Paint.Align.CENTER))
    }

    internal fun ellipsize(text: String, p: Paint, maxWidth: Float): String {
        val count = p.breakText(text, true, maxWidth, null)
        return if (count >= text.length) text else text.take((count - 1).coerceAtLeast(0)) + "…"
    }

    /** Prints any PDF built by [build]. */
    fun printDocument(context: Context, jobName: String, build: () -> PdfDocument) {
        val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(
            jobName,
            DocumentPrintAdapter(build),
            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
        )
    }

    /** Opens Android's print dialog (printers, "Save as PDF", etc.). */
    fun print(context: Context, data: MemoPrintData, jobName: String) {
        val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(
            jobName,
            DocumentPrintAdapter { buildDocument(data) },
            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
        )
    }
}

private class DocumentPrintAdapter(private val build: () -> PdfDocument) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        if (cancellationSignal.isCanceled) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder("document.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        try {
            val doc = build()
            FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }
            doc.close()
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message)
        }
    }
}
