MOBILE CLOUD BUILD - EasyLifeNote Step 5

1. Download and extract this ZIP on your phone.
2. Open your GitHub repository in a browser.
3. Upload the extracted project contents into the repository root (not the ZIP file).
4. Make sure the hidden .github/workflows/android-build.yml file is included.
   If GitHub mobile upload hides dot-folders, use GitHub's web desktop mode or
   upload the .github folder separately.
5. Commit the changes to main.
6. Open Actions -> Android Debug APK -> latest run.
7. After a successful green run, open Artifacts and download
   EasyLifeNote-debug-apk.

The workflow installs Gradle 8.9 on the GitHub runner and runs:
  gradle --no-daemon assembleDebug

The source ZIP does not include gradle-wrapper.jar. The GitHub workflow does not
use ./gradlew, so the hosted build can still run without that jar.

A successful workflow build is required before calling the APK verified.
