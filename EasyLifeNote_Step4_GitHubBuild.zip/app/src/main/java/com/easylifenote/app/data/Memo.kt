package com.easylifenote.app.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "memos")
data class Memo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyName: String,
    val phone: String,
    val address: String,
    val memoDate: String,
    val discount: Double = 0.0,
    val discountIsPercent: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "memo_items",
    foreignKeys = [ForeignKey(
        entity = Memo::class,
        parentColumns = ["id"],
        childColumns = ["memoId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("memoId")]
)
data class MemoItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memoId: Long,
    val name: String,
    val quantity: Double,
    val rate: Double
)

data class MemoWithItems(
    @Embedded val memo: Memo,
    @Relation(parentColumn = "id", entityColumn = "memoId")
    val items: List<MemoItem>
)
