package com.easylifenote.app.export

/** HTML pages used by the editor, the printer and the .doc export. */
object WordHtml {
    private const val BASE_CSS =
        "body{font-family:Arial,sans-serif;font-size:16px;line-height:1.5;color:#000;}" +
            "p{margin:0 0 8px 0;}" +
            "table{border-collapse:collapse;max-width:100%;}" +
            "td,th{border:1px solid #666;padding:6px;vertical-align:top;}" +
            "img{max-width:100%;}" +
            "ul,ol{margin:0 0 8px 0;padding-left:28px;}" +
            "*{-webkit-print-color-adjust:exact;print-color-adjust:exact;}"

    /** JavaScript used inside the editor page. (No dollar signs: this is a Kotlin string.) */
    private const val EDITOR_JS = """
var ed=document.getElementById('editor');
var saved=null;
document.addEventListener('selectionchange',function(){
  var s=window.getSelection();
  if(s.rangeCount&&ed.contains(s.anchorNode)){saved=s.getRangeAt(0).cloneRange();}
});
function restoreSel(){
  ed.focus();
  if(saved){var s=window.getSelection();s.removeAllRanges();s.addRange(saved);}
}
function cmd(n,v){
  restoreSel();
  document.execCommand('styleWithCSS',false,(n==='foreColor'||n==='hiliteColor'));
  document.execCommand(n,false,(v===undefined?null:v));
}
function setSize(px){
  restoreSel();
  document.execCommand('styleWithCSS',false,false);
  document.execCommand('fontSize',false,'7');
  var f=ed.querySelectorAll('font[size="7"]');
  for(var i=0;i<f.length;i++){f[i].removeAttribute('size');f[i].style.fontSize=px+'px';}
}
function selText(){restoreSel();return window.getSelection().toString();}
function insertTable(r,c){
  restoreSel();
  var h='<table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%">';
  for(var i=0;i<r;i++){
    h+='<tr>';
    for(var j=0;j<c;j++){h+='<td style="border:1px solid #666;padding:6px;vertical-align:top"><br></td>';}
    h+='</tr>';
  }
  h+='</table><p><br></p>';
  document.execCommand('insertHTML',false,h);
}
function cellOf(){
  var s=window.getSelection();
  if(!s.rangeCount){return null;}
  var n=s.anchorNode;
  while(n&&n!==ed){
    if(n.nodeName==='TD'||n.nodeName==='TH'){return n;}
    n=n.parentNode;
  }
  return null;
}
function mkCell(){
  var td=document.createElement('td');
  td.setAttribute('style','border:1px solid #666;padding:6px;vertical-align:top');
  td.innerHTML='<br>';
  return td;
}
function tableOp(op){
  restoreSel();
  var c=cellOf();
  if(!c){return 'nocell';}
  var tr=c.parentNode;
  var table=tr;
  while(table&&table.nodeName!=='TABLE'){table=table.parentNode;}
  if(!table){return 'nocell';}
  var ci=c.cellIndex;
  var ri=tr.rowIndex;
  var i;
  if(op==='rowBelow'||op==='rowAbove'){
    var nr=table.insertRow(op==='rowBelow'?ri+1:ri);
    for(i=0;i<tr.cells.length;i++){nr.appendChild(mkCell());}
  }else if(op==='colRight'||op==='colLeft'){
    var at=(op==='colRight')?ci+1:ci;
    for(i=0;i<table.rows.length;i++){
      var row=table.rows[i];
      row.insertBefore(mkCell(),row.cells[at]||null);
    }
  }else if(op==='delRow'){
    if(table.rows.length<=1){table.parentNode.removeChild(table);}else{table.deleteRow(ri);}
  }else if(op==='delCol'){
    for(i=0;i<table.rows.length;i++){
      if(table.rows[i].cells.length>ci){table.rows[i].deleteCell(ci);}
    }
    if(table.rows.length>0&&table.rows[0].cells.length===0){table.parentNode.removeChild(table);}
  }else if(op==='delTable'){
    table.parentNode.removeChild(table);
  }
  return 'ok';
}
"""

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    /** The editable page shown on screen. */
    fun editorPage(content: String): String = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>$BASE_CSS html,body{margin:0;padding:0;background:#fff;}
#editor{min-height:100vh;padding:14px;outline:none;word-wrap:break-word;overflow-wrap:break-word;}
td,th{min-width:36px;}</style></head>
<body><div id="editor" contenteditable="true">$content</div>
<script>$EDITOR_JS</script></body></html>"""

    /** Read-only page used for printing / PDF. */
    fun printPage(title: String, content: String): String = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>$BASE_CSS body{margin:0;padding:0;}</style></head>
<body>$content</body></html>"""

    /** Word-compatible HTML saved with a .doc extension (Microsoft Word opens it). */
    fun docPage(title: String, content: String): String = """<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${esc(title)}</title>
<style>$BASE_CSS</style></head>
<body>$content</body></html>"""
}
