package com.easylifenote.app.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** All memo calculations live here so screens and PDFs always agree. */
object MemoMath {
    fun round2(v: Double): Double = Math.round(v * 100.0) / 100.0

    fun lineTotal(qty: Double, rate: Double): Double = round2(qty * rate)

    fun subtotal(items: List<MemoItem>): Double = round2(items.sumOf { it.quantity * it.rate })

    fun discountAmount(subtotal: Double, discount: Double, isPercent: Boolean): Double {
        val raw = if (isPercent) subtotal * discount / 100.0 else discount
        return round2(raw.coerceIn(0.0, subtotal))
    }

    fun grandTotal(items: List<MemoItem>, discount: Double, isPercent: Boolean): Double {
        val sub = subtotal(items)
        return round2(sub - discountAmount(sub, discount, isPercent))
    }

    /** 1234.5 -> "1,234.50", 1000.0 -> "1,000" */
    fun fmt(v: Double): String {
        val s = String.format(Locale.US, "%,.2f", v)
        return if (s.endsWith(".00")) s.dropLast(3) else s
    }

    /** 5.0 -> "5", 2.5 -> "2.5" (for text fields) */
    fun plain(v: Double): String =
        if (v == Math.floor(v) && !v.isInfinite()) v.toLong().toString() else v.toString()

    /** Calculator output: up to 4 decimals, no trailing zeros. */
    fun calcFmt(v: Double): String =
        BigDecimal(v).setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

    fun isDecimalInput(s: String): Boolean = s.all { it.isDigit() || it == '.' } && s.count { it == '.' } <= 1

    fun formatDate(cal: Calendar): String = SimpleDateFormat("dd MMM yyyy", Locale.US).format(cal.time)

    fun today(): String = formatDate(Calendar.getInstance())
}
