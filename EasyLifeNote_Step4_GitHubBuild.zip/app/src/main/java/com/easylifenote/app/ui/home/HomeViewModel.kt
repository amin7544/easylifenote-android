package com.easylifenote.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.CompanyInfo
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).companyDao()

    val company: StateFlow<CompanyInfo> = dao.observe()
        .map { it ?: CompanyInfo() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CompanyInfo())

    fun save(info: CompanyInfo) {
        viewModelScope.launch { dao.upsert(info.copy(id = 1)) }
    }
}
