package com.easylifenote.app.data

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class ShiftTotal(val shift: Shift, val hours: Double, val amount: Double)

data class MonthSummary(
    val daysWorked: Int,
    val totalHours: Double,
    val overtimePay: Double,
    val byShift: List<ShiftTotal>
)

data class DaySummary(val date: String, val hours: Double, val amount: Double, val entries: List<OvertimeEntry>)

object OvertimeMath {
    fun multiplierFor(s: OvertimeSettings, shift: Shift): Double = when (shift) {
        Shift.DAY -> s.dayMultiplier
        Shift.NIGHT -> s.nightMultiplier
        Shift.REGULAR -> s.regularMultiplier
    }

    /** Pay for one record = hours x hourly rate x shift multiplier. */
    fun amount(hours: Double, hourlyRate: Double, multiplier: Double): Double =
        MemoMath.round2(hours * hourlyRate * multiplier)

    /** Basic salary / (working days x hours per day). */
    fun hourlyFromSalary(basic: Double, days: Int, hoursPerDay: Double): Double =
        if (days > 0 && hoursPerDay > 0) MemoMath.round2(basic / (days * hoursPerDay)) else 0.0

    fun summarize(entries: List<OvertimeEntry>): MonthSummary {
        val byShift = Shift.values().map { sh ->
            val list = entries.filter { it.shift == sh.name }
            ShiftTotal(sh, list.sumOf { it.hours }, MemoMath.round2(list.sumOf { it.amount }))
        }
        return MonthSummary(
            daysWorked = entries.map { it.date }.distinct().size,
            totalHours = entries.sumOf { it.hours },
            overtimePay = MemoMath.round2(entries.sumOf { it.amount }),
            byShift = byShift
        )
    }

    /** Groups records by day (input is already newest first). */
    fun byDay(entries: List<OvertimeEntry>): List<DaySummary> =
        entries.groupBy { it.date }.map { (date, list) ->
            DaySummary(date, list.sumOf { it.hours }, MemoMath.round2(list.sumOf { it.amount }), list)
        }

    fun hoursText(h: Double): String = MemoMath.fmt(h)

    fun prettyDate(iso: String): String = try {
        LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.US))
    } catch (e: Exception) { iso }

    fun monthLabel(m: YearMonth): String = m.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US))
}
