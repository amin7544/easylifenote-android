package com.easylifenote.app.ui.word

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.WordDocument
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class WordEditorViewModel(app: Application, handle: SavedStateHandle) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).documentDao()
    private val saveLock = Mutex()

    /** 0 = a new document that has not been saved yet. */
    private var currentId: Long = handle.get<Long>("id") ?: 0L
    private var createdAt: Long = System.currentTimeMillis()
    private var deleted = false
    private var lastHtml: String? = null
    private var lastTitle: String? = null

    var loading by mutableStateOf(true)
        private set
    var title by mutableStateOf("")
    var initialHtml by mutableStateOf("<p><br></p>")
        private set

    val isSaved: Boolean get() = currentId != 0L

    init {
        viewModelScope.launch {
            if (currentId != 0L) {
                val d = dao.get(currentId)
                if (d != null) {
                    title = d.title
                    initialHtml = d.html
                    lastHtml = d.html
                    lastTitle = d.title
                    createdAt = d.createdAt
                } else {
                    currentId = 0L
                }
            }
            loading = false
        }
    }

    private fun isBlank(html: String): Boolean {
        if (html.contains("<table", true) || html.contains("<img", true)) return false
        val text = html.replace(Regex("<[^>]*>"), "").replace("&nbsp;", " ").trim()
        return text.isEmpty()
    }

    /** onDone(null) = success (or nothing to save), otherwise an error message. */
    fun save(html: String, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            saveLock.withLock {
                if (deleted) {
                    onDone(null)
                    return@withLock
                }
                val t = title.trim()
                if (currentId == 0L && t.isEmpty() && isBlank(html)) {
                    onDone(null)   // empty new document: do not create it
                    return@withLock
                }
                if (currentId != 0L && html == lastHtml && t.ifEmpty { "Untitled document" } == lastTitle) {
                    onDone(null)   // nothing changed since the last save
                    return@withLock
                }
                try {
                    val doc = WordDocument(
                        id = currentId,
                        title = t.ifEmpty { "Untitled document" },
                        html = html,
                        createdAt = createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    currentId = dao.upsert(doc)
                    lastHtml = html
                    lastTitle = doc.title
                    onDone(null)
                } catch (e: Exception) {
                    onDone("Save failed: ${e.message}")
                }
            }
        }
    }

    fun deleteDocument(onDone: () -> Unit) {
        viewModelScope.launch {
            saveLock.withLock {
                deleted = true
                if (currentId != 0L) dao.delete(currentId)
            }
            onDone()
        }
    }
}
