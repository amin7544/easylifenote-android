package com.easylifenote.app.ui.overtime

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.data.MemoMath
import com.easylifenote.app.data.OvertimeEntry
import com.easylifenote.app.data.OvertimeMath
import com.easylifenote.app.data.OvertimeSettings
import com.easylifenote.app.data.Shift
import com.easylifenote.app.export.OvertimePdf
import com.easylifenote.app.export.OvertimePdfData
import com.easylifenote.app.export.OvertimePdfRow
import com.easylifenote.app.export.PdfExporter
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.common.ScreenHeader
import com.easylifenote.app.ui.common.WhiteCard
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.GreenA
import com.easylifenote.app.ui.theme.GreenB
import java.time.LocalDate
import java.time.YearMonth

private val Red = Color(0xFFD01C1C)

@Composable
fun OvertimeScreen(onBack: () -> Unit, vm: OvertimeViewModel = viewModel()) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val month by vm.month.collectAsStateWithLifecycle()
    val entries by vm.entries.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<OvertimeEntry?>(null) }

    val summary = OvertimeMath.summarize(entries)
    val days = OvertimeMath.byDay(entries)
    val totalSalary = MemoMath.round2(settings.basicSalary + summary.overtimePay)

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    fun pdfData() = OvertimePdfData(
        monthLabel = OvertimeMath.monthLabel(month),
        basicSalary = settings.basicSalary,
        hourlyRate = settings.hourlyRate,
        rows = entries.reversed().map {
            OvertimePdfRow(
                OvertimeMath.prettyDate(it.date), Shift.from(it.shift).label,
                it.hours, it.hourlyRate, it.multiplier, it.amount
            )
        },
        shiftLines = summary.byShift.filter { it.hours > 0 }.map {
            "${it.shift.label}: ${MemoMath.fmt(it.hours)} h = ${MemoMath.fmt(it.amount)}"
        },
        daysWorked = summary.daysWorked,
        totalHours = summary.totalHours,
        overtimePay = summary.overtimePay,
        totalSalary = totalSalary
    )

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    val doc = OvertimePdf.build(pdfData())
                    doc.writeTo(out)
                    doc.close()
                }
                toast("PDF saved successfully")
            } catch (e: Exception) {
                toast("Could not save PDF: ${e.message}")
            }
        }
    }

    fun pickDate() {
        DatePickerDialog(
            context,
            { _, y, m, d -> vm.date = LocalDate.of(y, m + 1, d) },
            vm.date.year, vm.date.monthValue - 1, vm.date.dayOfMonth
        ).show()
    }

    val liveHours = vm.hoursText.toDoubleOrNull() ?: 0.0
    val liveMult = OvertimeMath.multiplierFor(settings, vm.shift)
    val liveAmount = OvertimeMath.amount(liveHours, settings.hourlyRate, liveMult)

    GradientScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            ScreenHeader("Overtime Calculator", onBack)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ---------------- Salary information ----------------
                WhiteCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Salary Information", fontWeight = FontWeight.ExtraBold,
                            color = BlueDeep, fontSize = 17.sp, modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { showSettings = true }, colors = ButtonDefaults.buttonColors(containerColor = BlueMid)) {
                            Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                            Text(" Edit")
                        }
                    }
                    if (settings.hourlyRate <= 0.0) {
                        Text(
                            "Tap Edit and enter your basic salary and hourly rate to start.",
                            color = Red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                    SummaryRow("Basic salary", MemoMath.fmt(settings.basicSalary))
                    SummaryRow("Hourly rate", MemoMath.fmt(settings.hourlyRate))
                    SummaryRow(
                        "Multipliers",
                        "Day x${MemoMath.fmt(settings.dayMultiplier)}  Night x${MemoMath.fmt(settings.nightMultiplier)}  Regular x${MemoMath.fmt(settings.regularMultiplier)}"
                    )
                }

                // ---------------- Calculator ----------------
                WhiteCard {
                    Text(
                        if (vm.editingId == null) "Add Overtime" else "Edit Overtime Record",
                        fontWeight = FontWeight.ExtraBold, color = BlueDeep, fontSize = 17.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        OvertimeMath.prettyDate(vm.date.toString()), {}, readOnly = true,
                        label = { Text("Select date") }, singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { pickDate() }) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "Pick date", tint = BlueMid)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Shift type", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Shift.values().forEach { sh ->
                            ShiftButton(
                                sh.label, "x" + MemoMath.fmt(OvertimeMath.multiplierFor(settings, sh)),
                                vm.shift == sh, Modifier.weight(1f)
                            ) { vm.shift = sh }
                        }
                    }
                    OutlinedTextField(
                        vm.hoursText,
                        { if (MemoMath.isDecimalInput(it)) vm.hoursText = it },
                        label = { Text("Overtime hours") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    SummaryRow("Rate per hour", MemoMath.fmt(MemoMath.round2(settings.hourlyRate * liveMult)))
                    Row(
                        Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Overtime Pay", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = BlueDeep)
                        Text(MemoMath.fmt(liveAmount), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Red)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val wasEdit = vm.editingId != null
                                vm.save { err -> toast(err ?: if (wasEdit) "Record updated" else "Overtime saved") }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GreenA)
                        ) { Text(if (vm.editingId == null) "Save" else "Update", fontWeight = FontWeight.Bold) }
                        if (vm.editingId != null) {
                            OutlinedButton(onClick = { vm.cancelEdit() }, modifier = Modifier.weight(1f).height(48.dp)) {
                                Text("Cancel")
                            }
                        }
                    }
                }

                // ---------------- Monthly summary ----------------
                WhiteCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { vm.previousMonth() }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Previous month", tint = BlueMid)
                        }
                        Text(
                            OvertimeMath.monthLabel(month), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                            color = BlueDeep, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { vm.nextMonth() }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Next month", tint = BlueMid)
                        }
                    }
                    Text("Monthly Summary", fontWeight = FontWeight.Bold, color = BlueDeep)
                    SummaryRow("Days worked", summary.daysWorked.toString())
                    SummaryRow("Total overtime hours", MemoMath.fmt(summary.totalHours))
                    summary.byShift.forEach {
                        SummaryRow("   ${it.shift.label}", "${MemoMath.fmt(it.hours)} h  =  ${MemoMath.fmt(it.amount)}")
                    }
                    SummaryRow("Overtime pay", MemoMath.fmt(summary.overtimePay))
                    SummaryRow("Basic salary", MemoMath.fmt(settings.basicSalary))
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Salary", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = BlueDeep)
                        Text(MemoMath.fmt(totalSalary), fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = Red)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (entries.isEmpty()) toast("No records in this month.")
                                else PdfExporter.printDocument(context, "Overtime ${OvertimeMath.monthLabel(month)}") {
                                    OvertimePdf.build(pdfData())
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlueMid)
                        ) {
                            Icon(Icons.Default.Print, null, modifier = Modifier.size(18.dp))
                            Text(" Print", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                if (entries.isEmpty()) toast("No records in this month.")
                                else exportLauncher.launch("Overtime_${month}.pdf")
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Red)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, null, modifier = Modifier.size(18.dp))
                            Text(" Export PDF", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // ---------------- Daily records ----------------
                WhiteCard {
                    Text("Daily Records", fontWeight = FontWeight.ExtraBold, color = BlueDeep, fontSize = 17.sp)
                    if (days.isEmpty()) {
                        Text(
                            "No overtime saved for ${OvertimeMath.monthLabel(month)}.",
                            color = Color.DarkGray, fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth().padding(14.dp), textAlign = TextAlign.Center
                        )
                    }
                    days.forEach { day ->
                        Row(
                            Modifier.fillMaxWidth().padding(top = 10.dp).background(BlueMid).padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                OvertimeMath.prettyDate(day.date), color = Color.White,
                                fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f)
                            )
                            Text(
                                "${MemoMath.fmt(day.hours)} h  |  ${MemoMath.fmt(day.amount)}",
                                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
                            )
                        }
                        day.entries.forEach { e ->
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.startEdit(e) }.padding(start = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                                    Text(Shift.from(e.shift).label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "${MemoMath.fmt(e.hours)} h x ${MemoMath.fmt(e.hourlyRate)} x ${MemoMath.fmt(e.multiplier)}",
                                        fontSize = 12.sp, color = Color.DarkGray
                                    )
                                }
                                Text(MemoMath.fmt(e.amount), fontWeight = FontWeight.Bold, color = BlueDeep)
                                IconButton(onClick = { toDelete = e }) {
                                    Icon(Icons.Default.Delete, "Delete record", tint = Red)
                                }
                            }
                        }
                    }
                    if (days.isNotEmpty()) {
                        Text("Tap a record to edit it.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            current = settings,
            onDismiss = { showSettings = false },
            onSave = { vm.saveSettings(it); showSettings = false }
        )
    }
    toDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete record?") },
            text = { Text("${OvertimeMath.prettyDate(e.date)} - ${Shift.from(e.shift).label}, ${MemoMath.fmt(e.hours)} h") },
            confirmButton = {
                TextButton(onClick = { vm.delete(e.id); toDelete = null }) { Text("Delete", color = Red) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 14.sp, color = Color.DarkGray)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

@Composable
private fun ShiftButton(label: String, mult: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        contentPadding = PaddingValues(horizontal = 4.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) BlueMid else Color(0xFFD5E0F7),
            contentColor = if (selected) Color.White else BlueDeep
        )
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(mult, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsDialog(current: OvertimeSettings, onDismiss: () -> Unit, onSave: (OvertimeSettings) -> Unit) {
    var basic by remember { mutableStateOf(if (current.basicSalary > 0) MemoMath.plain(current.basicSalary) else "") }
    var hourly by remember { mutableStateOf(if (current.hourlyRate > 0) MemoMath.plain(current.hourlyRate) else "") }
    var days by remember { mutableStateOf(current.daysPerMonth.toString()) }
    var hoursPerDay by remember { mutableStateOf(MemoMath.plain(current.hoursPerDay)) }
    var dayM by remember { mutableStateOf(MemoMath.plain(current.dayMultiplier)) }
    var nightM by remember { mutableStateOf(MemoMath.plain(current.nightMultiplier)) }
    var regularM by remember { mutableStateOf(MemoMath.plain(current.regularMultiplier)) }
    var error by remember { mutableStateOf<String?>(null) }

    val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Salary Information") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    basic, { if (MemoMath.isDecimalInput(it)) basic = it },
                    label = { Text("Basic monthly salary") }, singleLine = true, keyboardOptions = decimal
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        days, { if (it.all { c -> c.isDigit() } && it.length <= 2) days = it },
                        label = { Text("Days/month") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        hoursPerDay, { if (MemoMath.isDecimalInput(it)) hoursPerDay = it },
                        label = { Text("Hours/day") }, singleLine = true, keyboardOptions = decimal,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    hourly, { if (MemoMath.isDecimalInput(it)) hourly = it },
                    label = { Text("Hourly rate") }, singleLine = true, keyboardOptions = decimal
                )
                TextButton(onClick = {
                    val r = OvertimeMath.hourlyFromSalary(
                        basic.toDoubleOrNull() ?: 0.0, days.toIntOrNull() ?: 0, hoursPerDay.toDoubleOrNull() ?: 0.0
                    )
                    if (r > 0) hourly = MemoMath.plain(r) else error = "Enter salary, days and hours first."
                }) { Text("Calculate hourly rate from salary") }
                Text("Shift multipliers", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        dayM, { if (MemoMath.isDecimalInput(it)) dayM = it },
                        label = { Text("Day") }, singleLine = true, keyboardOptions = decimal, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        nightM, { if (MemoMath.isDecimalInput(it)) nightM = it },
                        label = { Text("Night") }, singleLine = true, keyboardOptions = decimal, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        regularM, { if (MemoMath.isDecimalInput(it)) regularM = it },
                        label = { Text("Regular") }, singleLine = true, keyboardOptions = decimal, modifier = Modifier.weight(1f)
                    )
                }
                error?.let { Text(it, color = Red, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val h = hourly.toDoubleOrNull() ?: 0.0
                val d = dayM.toDoubleOrNull() ?: 0.0
                val n = nightM.toDoubleOrNull() ?: 0.0
                val r = regularM.toDoubleOrNull() ?: 0.0
                when {
                    h <= 0.0 -> error = "Enter an hourly rate greater than 0."
                    d <= 0.0 || n <= 0.0 || r <= 0.0 -> error = "Multipliers must be greater than 0."
                    else -> onSave(
                        OvertimeSettings(
                            id = 1,
                            basicSalary = basic.toDoubleOrNull() ?: 0.0,
                            hourlyRate = h,
                            daysPerMonth = days.toIntOrNull() ?: 26,
                            hoursPerDay = hoursPerDay.toDoubleOrNull() ?: 8.0,
                            dayMultiplier = d, nightMultiplier = n, regularMultiplier = r
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
