package com.easylifenote.app.export

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.easylifenote.app.data.MemoMath

data class OvertimePdfRow(
    val date: String,
    val shift: String,
    val hours: Double,
    val rate: Double,
    val multiplier: Double,
    val amount: Double
)

data class OvertimePdfData(
    val monthLabel: String,
    val basicSalary: Double,
    val hourlyRate: Double,
    val rows: List<OvertimePdfRow>,
    val shiftLines: List<String>,   // e.g. "Day: 12.5 h = 9,375"
    val daysWorked: Int,
    val totalHours: Double,
    val overtimePay: Double,
    val totalSalary: Double
)

object OvertimePdf {
    private const val W = PdfExporter.W
    private const val H = PdfExporter.H
    private const val M = PdfExporter.M

    fun build(d: OvertimePdfData): PdfDocument {
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var canvas = page.canvas
        PdfExporter.drawFooter(canvas, pageNo)
        var y = header(canvas, d)
        y = tableHeader(canvas, y)

        for ((i, row) in d.rows.withIndex()) {
            if (y > H - 80f) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
                canvas = page.canvas
                PdfExporter.drawFooter(canvas, pageNo)
                y = tableHeader(canvas, M + 10f)
            }
            y = row(canvas, y, i, row)
        }

        if (y > H - 200f) {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            canvas = page.canvas
            PdfExporter.drawFooter(canvas, pageNo)
            y = M + 10f
        }
        summary(canvas, y + 14f, d)
        doc.finishPage(page)
        return doc
    }

    private fun header(c: Canvas, d: OvertimePdfData): Float {
        c.drawRect(0f, 0f, W.toFloat(), 96f, PdfExporter.fill(PdfExporter.BLUE))
        c.drawText("Overtime Report", M, 42f, PdfExporter.paint(22f, true, Color.WHITE))
        c.drawText(d.monthLabel, M, 62f, PdfExporter.paint(12f, false, Color.WHITE))
        c.drawText(
            "Basic salary: ${MemoMath.fmt(d.basicSalary)}   |   Hourly rate: ${MemoMath.fmt(d.hourlyRate)}",
            M, 80f, PdfExporter.paint(11f, false, Color.WHITE)
        )
        c.drawText("Easy Life Note", W - M, 42f, PdfExporter.paint(14f, true, Color.WHITE, Paint.Align.RIGHT))
        return 116f
    }

    private fun tableHeader(c: Canvas, y: Float): Float {
        c.drawRect(M, y, W - M, y + 24f, PdfExporter.fill(PdfExporter.BLUE))
        val p = PdfExporter.paint(11f, true, Color.WHITE)
        val r = PdfExporter.paint(11f, true, Color.WHITE, Paint.Align.RIGHT)
        c.drawText("Date", M + 6f, y + 16f, p)
        c.drawText("Shift", M + 150f, y + 16f, p)
        c.drawText("Hours", 350f, y + 16f, r)
        c.drawText("Rate", 415f, y + 16f, r)
        c.drawText("x", 455f, y + 16f, r)
        c.drawText("Amount", W - M - 6f, y + 16f, r)
        return y + 24f
    }

    private fun row(c: Canvas, y: Float, index: Int, row: OvertimePdfRow): Float {
        if (index % 2 == 1) c.drawRect(M, y, W - M, y + 22f, PdfExporter.fill(PdfExporter.LIGHT))
        val p = PdfExporter.paint(11f)
        val r = PdfExporter.paint(11f, false, Color.BLACK, Paint.Align.RIGHT)
        c.drawText(PdfExporter.ellipsize(row.date, p, 140f), M + 6f, y + 15f, p)
        c.drawText(row.shift, M + 150f, y + 15f, p)
        c.drawText(MemoMath.fmt(row.hours), 350f, y + 15f, r)
        c.drawText(MemoMath.fmt(row.rate), 415f, y + 15f, r)
        c.drawText(MemoMath.fmt(row.multiplier), 455f, y + 15f, r)
        c.drawText(MemoMath.fmt(row.amount), W - M - 6f, y + 15f, r)
        c.drawLine(M, y + 22f, W - M, y + 22f, PdfExporter.fill(Color.LTGRAY))
        return y + 22f
    }

    private fun summary(c: Canvas, y: Float, d: OvertimePdfData) {
        // left: shift breakdown
        c.drawText("By shift", M, y + 14f, PdfExporter.paint(12f, true))
        d.shiftLines.forEachIndexed { i, line ->
            c.drawText(line, M, y + 34f + i * 18f, PdfExporter.paint(11f))
        }
        // right: totals
        val label = PdfExporter.paint(12f, true)
        val value = PdfExporter.paint(12f, false, Color.BLACK, Paint.Align.RIGHT)
        val x = 340f
        val right = W - M - 6f
        c.drawText("Days worked", x, y + 14f, label)
        c.drawText(d.daysWorked.toString(), right, y + 14f, value)
        c.drawText("Total overtime hours", x, y + 34f, label)
        c.drawText(MemoMath.fmt(d.totalHours), right, y + 34f, value)
        c.drawText("Overtime pay", x, y + 54f, label)
        c.drawText(MemoMath.fmt(d.overtimePay), right, y + 54f, value)
        c.drawText("Basic salary", x, y + 74f, label)
        c.drawText(MemoMath.fmt(d.basicSalary), right, y + 74f, value)
        c.drawRect(x - 8f, y + 86f, W - M, y + 118f, PdfExporter.fill(PdfExporter.BLUE))
        c.drawText("Total Salary", x, y + 108f, PdfExporter.paint(14f, true, Color.WHITE))
        c.drawText(MemoMath.fmt(d.totalSalary), right, y + 108f, PdfExporter.paint(15f, true, Color.WHITE, Paint.Align.RIGHT))
    }
}
