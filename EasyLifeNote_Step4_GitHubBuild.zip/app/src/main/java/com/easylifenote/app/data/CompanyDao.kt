package com.easylifenote.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM company_info WHERE id = 1")
    fun observe(): Flow<CompanyInfo?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(info: CompanyInfo)
}
