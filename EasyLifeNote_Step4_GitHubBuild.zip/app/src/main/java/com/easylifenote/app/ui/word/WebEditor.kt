package com.easylifenote.app.ui.word

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener

/** Thin wrapper that sends editing commands to the page inside the WebView. */
class WebEditor(private val web: WebView) {

    private fun run(js: String) = web.evaluateJavascript(js, null)

    fun undo() = run("cmd('undo')")
    fun redo() = run("cmd('redo')")
    fun bold() = run("cmd('bold')")
    fun italic() = run("cmd('italic')")
    fun underline() = run("cmd('underline')")
    fun fontName(css: String) = run("cmd('fontName','$css')")
    fun fontSize(px: Int) = run("setSize($px)")
    fun textColor(hex: String) = run("cmd('foreColor','$hex')")
    fun highlight(hex: String) = run("cmd('hiliteColor','$hex')")
    fun alignLeft() = run("cmd('justifyLeft')")
    fun alignCenter() = run("cmd('justifyCenter')")
    fun alignRight() = run("cmd('justifyRight')")
    fun alignJustify() = run("cmd('justifyFull')")
    fun bullets() = run("cmd('insertUnorderedList')")
    fun numbering() = run("cmd('insertOrderedList')")
    fun selectAll() = run("cmd('selectAll')")
    fun insertTable(rows: Int, cols: Int) = run("insertTable($rows,$cols)")

    /** op: rowBelow, rowAbove, colRight, colLeft, delRow, delCol, delTable. Callback gets "ok" or "nocell". */
    fun tableOp(op: String, onResult: (String) -> Unit) {
        web.evaluateJavascript("tableOp('$op')") { onResult(decode(it)) }
    }

    fun getHtml(onResult: (String) -> Unit) {
        web.evaluateJavascript("document.getElementById('editor').innerHTML") { onResult(decode(it)) }
    }

    /** Copies (or cuts) the selected text to the Android clipboard. Returns false when nothing is selected. */
    fun copy(context: Context, cut: Boolean, onDone: (Boolean) -> Unit) {
        web.evaluateJavascript("selText()") { raw ->
            val text = decode(raw)
            if (text.isEmpty()) {
                onDone(false)
            } else {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Easy Life Note", text))
                if (cut) run("cmd('delete')")
                onDone(true)
            }
        }
    }

    /** Pastes the clipboard text at the cursor. Returns false when the clipboard has no text. */
    fun paste(context: Context): Boolean {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip == null || clip.itemCount == 0) return false
        val text = clip.getItemAt(0).coerceToText(context)?.toString().orEmpty()
        if (text.isEmpty()) return false
        run("restoreSel();document.execCommand('insertText',false," + JSONObject.quote(text) + ");")
        return true
    }

    companion object {
        /** evaluateJavascript returns a JSON value; turn it into a plain string. */
        fun decode(raw: String?): String {
            if (raw == null || raw == "null") return ""
            return try {
                JSONTokener(raw).nextValue() as? String ?: ""
            } catch (e: Exception) {
                ""
            }
        }
    }
}
