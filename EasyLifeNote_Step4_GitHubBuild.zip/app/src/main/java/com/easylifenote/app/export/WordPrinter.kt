package com.easylifenote.app.export

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient

/** Prints a document through Android's print system (also gives "Save as PDF"). */
object WordPrinter {
    // Keep a reference so the WebView is not garbage-collected while the print dialog is open.
    private var keep: WebView? = null

    fun print(context: Context, title: String, contentHtml: String) {
        val web = WebView(context)
        web.settings.javaScriptEnabled = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (view == null) return
                val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = view.createPrintDocumentAdapter(title)
                pm.print(
                    title,
                    adapter,
                    PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
                )
            }
        }
        keep = web
        web.loadDataWithBaseURL(null, WordHtml.printPage(title, contentHtml), "text/html", "utf-8", null)
    }
}
