package com.easylifenote.app.ui.word

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.data.WordDocument
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.common.ScreenHeader
import com.easylifenote.app.ui.common.WhiteCard
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.Gold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WordListScreen(
    onBack: () -> Unit,
    onOpen: (Long) -> Unit,
    vm: WordListViewModel = viewModel()
) {
    val docs by vm.documents.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<WordDocument?>(null) }
    var toRename by remember { mutableStateOf<WordDocument?>(null) }

    GradientScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            ScreenHeader("Microsoft Word", onBack)
            val list = docs
            when {
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White)
                }
                list.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No documents yet.\nTap the + button to write your first document.",
                        color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center
                    )
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(list, key = { it.id }) { d ->
                        DocCard(d, onClick = { onOpen(d.id) }, onRename = { toRename = d }, onDelete = { toDelete = d })
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { onOpen(0L) },
            containerColor = Gold,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "New document", tint = BlueDeep)
        }
    }

    toRename?.let { d ->
        var name by remember(d.id) { mutableStateOf(d.title) }
        AlertDialog(
            onDismissRequest = { toRename = null },
            title = { Text("Rename document") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Document title") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.rename(d.id, name); toRename = null }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { toRename = null }) { Text("Cancel") } }
        )
    }

    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete document?") },
            text = { Text("\"${d.title}\" will be deleted permanently.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(d.id); toDelete = null }) {
                    Text("Delete", color = Color(0xFFD01C1C))
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DocCard(d: WordDocument, onClick: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val snippet = remember(d.updatedAt, d.id) {
        HtmlCompat.fromHtml(d.html.take(3000), HtmlCompat.FROM_HTML_MODE_COMPACT)
            .toString().replace(Regex("\\s+"), " ").trim().take(90)
    }
    val date = remember(d.updatedAt) {
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date(d.updatedAt))
    }
    WhiteCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    d.title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = BlueDeep,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (snippet.isNotEmpty()) {
                    Text(snippet, fontSize = 13.sp, color = Color.DarkGray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Text("Edited $date", fontSize = 11.sp, color = Color.Gray)
            }
            IconButton(onClick = onRename) {
                Icon(Icons.Default.Edit, contentDescription = "Rename document", tint = BlueMid)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete document", tint = BlueMid)
            }
        }
    }
}
