package com.easylifenote.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class MemoDao {
    @Transaction
    @Query("SELECT * FROM memos ORDER BY createdAt DESC")
    abstract fun observeAll(): Flow<List<MemoWithItems>>

    @Transaction
    @Query("SELECT * FROM memos WHERE id = :id")
    abstract suspend fun getWithItems(id: Long): MemoWithItems?

    @Insert
    abstract suspend fun insertMemo(memo: Memo): Long

    @Update
    abstract suspend fun updateMemo(memo: Memo)

    @Insert
    abstract suspend fun insertItems(items: List<MemoItem>)

    @Query("DELETE FROM memo_items WHERE memoId = :memoId")
    abstract suspend fun deleteItemsOf(memoId: Long)

    @Query("DELETE FROM memos WHERE id = :id")
    abstract suspend fun deleteMemo(id: Long)

    /** Saves a memo and all of its rows in one safe transaction. Returns the memo id. */
    @Transaction
    open suspend fun saveMemo(memo: Memo, items: List<MemoItem>): Long {
        val id = if (memo.id == 0L) insertMemo(memo) else { updateMemo(memo); memo.id }
        deleteItemsOf(id)
        insertItems(items.map { it.copy(id = 0, memoId = id) })
        return id
    }
}
