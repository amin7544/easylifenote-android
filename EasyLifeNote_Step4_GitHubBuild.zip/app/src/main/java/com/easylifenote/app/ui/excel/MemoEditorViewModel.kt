package com.easylifenote.app.ui.excel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.CompanyInfo
import com.easylifenote.app.data.Memo
import com.easylifenote.app.data.MemoItem
import com.easylifenote.app.data.MemoMath
import com.easylifenote.app.export.MemoPrintData
import com.easylifenote.app.export.PrintRow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MemoEditorViewModel(app: Application, handle: SavedStateHandle) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val memoDao = db.memoDao()

    /** 0 = a new memo that has not been saved yet. */
    private var currentId: Long = handle.get<Long>("id") ?: 0L
    private var createdAt: Long = System.currentTimeMillis()
    private var tempId = -1L

    var loading by mutableStateOf(true)
        private set

    var companyName by mutableStateOf("")
    var phone by mutableStateOf("")
    var address by mutableStateOf("")
    var date by mutableStateOf("")
    var discountText by mutableStateOf("")
    var discountIsPercent by mutableStateOf(false)
    val items = mutableStateListOf<MemoItem>()

    val subtotal: Double get() = MemoMath.subtotal(items)
    val discountAmount: Double
        get() = MemoMath.discountAmount(subtotal, discountText.toDoubleOrNull() ?: 0.0, discountIsPercent)
    val grandTotal: Double get() = MemoMath.round2(subtotal - discountAmount)

    init {
        viewModelScope.launch {
            if (currentId == 0L) {
                val c = db.companyDao().observe().first() ?: CompanyInfo()
                companyName = c.name
                phone = c.phone
                address = c.address
                date = MemoMath.today()
            } else {
                val m = memoDao.getWithItems(currentId)
                if (m != null) {
                    companyName = m.memo.companyName
                    phone = m.memo.phone
                    address = m.memo.address
                    date = m.memo.memoDate
                    discountText = if (m.memo.discount > 0) MemoMath.plain(m.memo.discount) else ""
                    discountIsPercent = m.memo.discountIsPercent
                    createdAt = m.memo.createdAt
                    items.addAll(m.items)
                } else {
                    currentId = 0L
                    date = MemoMath.today()
                }
            }
            loading = false
        }
    }

    fun addItem(name: String, qty: Double, rate: Double) {
        items.add(MemoItem(id = tempId--, memoId = 0, name = name, quantity = qty, rate = rate))
    }

    fun updateItem(id: Long, name: String, qty: Double, rate: Double) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = items[i].copy(name = name, quantity = qty, rate = rate)
    }

    fun deleteItem(id: Long) {
        items.removeAll { it.id == id }
    }

    /** onResult(null) = success, otherwise an error message. */
    fun save(onResult: (String?) -> Unit) {
        if (items.isEmpty()) {
            onResult("Add at least one item first.")
            return
        }
        viewModelScope.launch {
            try {
                val memo = Memo(
                    id = currentId,
                    companyName = companyName.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    memoDate = date,
                    discount = discountText.toDoubleOrNull() ?: 0.0,
                    discountIsPercent = discountIsPercent,
                    createdAt = createdAt
                )
                currentId = memoDao.saveMemo(memo, items.toList())
                onResult(null)
            } catch (e: Exception) {
                onResult("Save failed: ${e.message}")
            }
        }
    }

    fun printData(): MemoPrintData {
        val d = discountText.toDoubleOrNull() ?: 0.0
        val label = if (discountIsPercent) "Discount (${MemoMath.fmt(d)}%)" else "Discount"
        return MemoPrintData(
            companyName = companyName,
            phone = phone,
            address = address,
            date = date,
            rows = items.map { PrintRow(it.name, it.quantity, it.rate, MemoMath.lineTotal(it.quantity, it.rate)) },
            subtotal = subtotal,
            discountLabel = label,
            discountAmount = discountAmount,
            grandTotal = grandTotal
        )
    }
}
