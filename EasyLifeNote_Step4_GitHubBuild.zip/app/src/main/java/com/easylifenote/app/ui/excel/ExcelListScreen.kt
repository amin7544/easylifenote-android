package com.easylifenote.app.ui.excel

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.data.MemoMath
import com.easylifenote.app.data.MemoWithItems
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.common.ScreenHeader
import com.easylifenote.app.ui.common.WhiteCard
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.Gold

@Composable
fun ExcelListScreen(
    onBack: () -> Unit,
    onOpen: (Long) -> Unit,
    vm: ExcelListViewModel = viewModel()
) {
    val memos by vm.memos.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<MemoWithItems?>(null) }

    GradientScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            ScreenHeader("Excel Sheet", onBack)
            val list = memos
            when {
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White)
                }
                list.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No memos yet.\nTap the + button to create your first memo.",
                        color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center
                    )
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(list, key = { it.memo.id }) { m ->
                        MemoCard(m, onClick = { onOpen(m.memo.id) }, onDelete = { toDelete = m })
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { onOpen(0L) },
            containerColor = Gold,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "New memo", tint = BlueDeep)
        }
    }

    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete memo?") },
            text = { Text("This memo and all its rows will be deleted permanently.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(m.memo.id); toDelete = null }) {
                    Text("Delete", color = Color(0xFFD01C1C))
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MemoCard(m: MemoWithItems, onClick: () -> Unit, onDelete: () -> Unit) {
    val total = MemoMath.grandTotal(m.items, m.memo.discount, m.memo.discountIsPercent)
    WhiteCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    m.memo.companyName.ifBlank { "Untitled memo" },
                    fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = BlueDeep,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("${m.memo.memoDate}  •  ${m.items.size} item(s)", fontSize = 12.sp, color = Color.DarkGray)
                Text("Total: ${MemoMath.fmt(total)}", fontWeight = FontWeight.Bold, color = Color(0xFFD01C1C), fontSize = 16.sp)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete memo", tint = BlueMid)
            }
        }
    }
}
