package com.easylifenote.app.ui.overtime

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.OvertimeEntry
import com.easylifenote.app.data.OvertimeMath
import com.easylifenote.app.data.OvertimeSettings
import com.easylifenote.app.data.Shift
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalCoroutinesApi::class)
class OvertimeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).overtimeDao()

    val settings: StateFlow<OvertimeSettings> = dao.observeSettings()
        .map { it ?: OvertimeSettings() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OvertimeSettings())

    /** Month currently shown in the summary. */
    val month = MutableStateFlow(YearMonth.now())

    val entries: StateFlow<List<OvertimeEntry>> = month
        .flatMapLatest { dao.observeMonth(it.toString()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- calculator form ----
    var date by mutableStateOf(LocalDate.now())
    var shift by mutableStateOf(Shift.DAY)
    var hoursText by mutableStateOf("")
    var editingId by mutableStateOf<Long?>(null)
        private set

    fun previousMonth() { month.value = month.value.minusMonths(1) }
    fun nextMonth() { month.value = month.value.plusMonths(1) }

    fun saveSettings(s: OvertimeSettings) {
        viewModelScope.launch { dao.saveSettings(s.copy(id = 1)) }
    }

    /** onResult(null) = saved, otherwise an error message. */
    fun save(onResult: (String?) -> Unit) {
        val s = settings.value
        val hours = hoursText.toDoubleOrNull()
        if (s.hourlyRate <= 0.0) {
            onResult("Set your hourly rate first (Salary Information → Edit).")
            return
        }
        if (hours == null || hours <= 0.0) {
            onResult("Enter the overtime hours.")
            return
        }
        if (hours > 24.0) {
            onResult("Overtime hours cannot be more than 24 in a day.")
            return
        }
        val mult = OvertimeMath.multiplierFor(s, shift)
        val entry = OvertimeEntry(
            id = editingId ?: 0L,
            date = date.toString(),
            shift = shift.name,
            hours = hours,
            hourlyRate = s.hourlyRate,
            multiplier = mult,
            amount = OvertimeMath.amount(hours, s.hourlyRate, mult)
        )
        viewModelScope.launch {
            try {
                dao.upsert(entry)
                month.value = YearMonth.from(date)
                hoursText = ""
                editingId = null
                onResult(null)
            } catch (e: Exception) {
                onResult("Save failed: ${e.message}")
            }
        }
    }

    fun startEdit(e: OvertimeEntry) {
        editingId = e.id
        date = LocalDate.parse(e.date)
        shift = Shift.from(e.shift)
        hoursText = com.easylifenote.app.data.MemoMath.plain(e.hours)
    }

    fun cancelEdit() {
        editingId = null
        hoursText = ""
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            dao.delete(id)
            if (editingId == id) cancelEdit()
        }
    }
}
