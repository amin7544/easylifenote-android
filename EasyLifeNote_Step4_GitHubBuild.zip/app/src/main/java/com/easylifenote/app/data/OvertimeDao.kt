package com.easylifenote.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OvertimeDao {
    @Query("SELECT * FROM overtime_settings WHERE id = 1")
    fun observeSettings(): Flow<OvertimeSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: OvertimeSettings)

    /** month = "2026-11" */
    @Query("SELECT * FROM overtime_entries WHERE date LIKE :month || '%' ORDER BY date DESC, id DESC")
    fun observeMonth(month: String): Flow<List<OvertimeEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: OvertimeEntry): Long

    @Query("DELETE FROM overtime_entries WHERE id = :id")
    suspend fun delete(id: Long)
}
