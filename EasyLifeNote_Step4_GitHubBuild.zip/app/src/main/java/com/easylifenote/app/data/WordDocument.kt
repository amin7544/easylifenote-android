package com.easylifenote.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** A saved document. The content is stored as HTML (what the editor produces). */
@Entity(tableName = "documents")
data class WordDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val html: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<WordDocument>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun get(id: Long): WordDocument?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(doc: WordDocument): Long

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE documents SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: Long, title: String, now: Long)
}
