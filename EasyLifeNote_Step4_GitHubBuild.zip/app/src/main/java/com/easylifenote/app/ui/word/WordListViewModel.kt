package com.easylifenote.app.ui.word

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.WordDocument
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WordListViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).documentDao()

    /** null = still loading */
    val documents: StateFlow<List<WordDocument>?> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun rename(id: Long, title: String) {
        val t = title.trim().ifEmpty { "Untitled document" }
        viewModelScope.launch { dao.rename(id, t, System.currentTimeMillis()) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { dao.delete(id) }
    }
}
