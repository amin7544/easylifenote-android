package com.easylifenote.app.ui.excel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.easylifenote.app.data.AppDatabase
import com.easylifenote.app.data.MemoWithItems
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExcelListViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).memoDao()

    /** null = still loading */
    val memos: StateFlow<List<MemoWithItems>?> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun delete(id: Long) {
        viewModelScope.launch { dao.deleteMemo(id) }
    }
}
