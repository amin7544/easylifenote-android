package com.easylifenote.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "company_info")
data class CompanyInfo(
    @PrimaryKey val id: Int = 1,
    val name: String = "Your Company Info",
    val phone: String = "01712-345678",
    val address: String = "Netrokona, Dhaka, Bangladesh"
)
