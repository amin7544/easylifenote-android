package com.easylifenote.app.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.R
import com.easylifenote.app.data.CompanyInfo
import com.easylifenote.app.ui.Routes
import com.easylifenote.app.ui.theme.*

@Composable
fun HomeScreen(onOpen: (String) -> Unit, vm: HomeViewModel = viewModel()) {
    val company by vm.company.collectAsStateWithLifecycle()
    var showEdit by remember { mutableStateOf(false) }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(BlueDeep, BlueMid, BlueSky)))
    ) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TopBar()
            Banner()
            CompanyCard(company) { showEdit = true }
            FeatureGrid(onOpen)
            QuickActions(onOpen)
            SyncCard(onOpen)
            Text(
                "© 2025 Easy Life Note. All Rights Reserved.",
                color = Color.White, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }

    if (showEdit) {
        EditCompanyDialog(company, onDismiss = { showEdit = false }) {
            vm.save(it); showEdit = false
        }
    }
}

@Composable
private fun TopBar() {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.EditNote, null, tint = Gold, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("Easy Life Note", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Work Smart, Live Better", color = Color.White, fontSize = 13.sp, fontStyle = FontStyle.Italic)
        }
        Icon(Icons.Default.Notifications, null, tint = Color.White, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun Banner() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Image(
            painter = painterResource(R.drawable.banner_character),
            contentDescription = "Easy Life Note character",
            contentScale = ContentScale.Crop,
            modifier = Modifier.width(150.dp).height(215.dp).clip(RoundedCornerShape(20.dp))
        )
        Column(Modifier.weight(1f)) {
            Text("Welcome", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic)
            Text("Back!", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic)
            Text("Your Productivity Partner", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            NotepadCard()
        }
    }
}

@Composable
private fun NotepadCard() {
    Column(
        Modifier.rotate(3f).shadow(6.dp, RoundedCornerShape(10.dp))
            .background(Color.White, RoundedCornerShape(10.dp)).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("Plan", "Calculate", "Remember").forEach {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = GreenA, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(it, color = BlueDeep, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 15.sp)
            }
        }
        Text("Easy Life Note", color = Color(0xFFD01C1C), fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 14.sp)
    }
}

@Composable
private fun CompanyCard(info: CompanyInfo, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(CardWhite, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Business, null, tint = BlueMid, modifier = Modifier.size(44.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(info.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = BlueDeep)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, null, tint = BlueMid, modifier = Modifier.size(16.dp))
                Text(" " + info.phone, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, null, tint = Color(0xFFD01C1C), modifier = Modifier.size(16.dp))
                Text(" " + info.address, fontSize = 13.sp)
            }
        }
        Button(onClick = onEdit, colors = ButtonDefaults.buttonColors(containerColor = BlueMid)) {
            Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Edit")
        }
    }
}

@Composable
private fun FeatureGrid(onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureTile("Excel Sheet", "Make Memo & Calculate", Icons.Default.TableChart,
                listOf(GreenA, GreenB), Modifier.weight(1f)) { onOpen(Routes.EXCEL) }
            FeatureTile("Microsoft Words", "All Functions", Icons.Default.Description,
                listOf(BlueSky, BlueMid), Modifier.weight(1f)) { onOpen(Routes.WORD) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureTile("Overtime Calculator", "Calculate Salary", Icons.Default.AccessTime,
                listOf(BlueSky, BlueMid), Modifier.weight(1f)) { onOpen(Routes.OVERTIME) }
            FeatureTile("Reminder", "Never Miss Important Things", Icons.Default.Notifications,
                listOf(PurpleA, PurpleB), Modifier.weight(1f)) { onOpen(Routes.REMINDER) }
        }
    }
}

@Composable
private fun FeatureTile(
    title: String, subtitle: String, icon: ImageVector,
    colors: List<Color>, modifier: Modifier, onClick: () -> Unit
) {
    Column(
        modifier.height(130.dp).shadow(6.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(colors))
            .clickable(onClick = onClick).padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(40.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, lineHeight = 19.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(subtitle, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Box(Modifier.size(26.dp).background(Color.White.copy(alpha = 0.3f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun QuickActions(onOpen: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(CardWhite, RoundedCornerShape(20.dp)).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        QuickItem("Print", "Print Your Data", Icons.Default.Print, BlueMid) { onOpen(Routes.PRINT) }
        QuickItem("Export to PDF", "Save & Share", Icons.Default.PictureAsPdf, Color(0xFFD01C1C)) { onOpen(Routes.PDF) }
        QuickItem("About", "App Information", Icons.Default.Info, BlueMid) { onOpen(Routes.ABOUT) }
    }
}

@Composable
private fun QuickItem(title: String, sub: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(34.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BlueDeep)
        Text(sub, fontSize = 10.sp, color = Color.DarkGray)
    }
}

@Composable
private fun SyncCard(onOpen: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(CardWhite, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.CloudSync, null, tint = BlueMid, modifier = Modifier.size(36.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Google Drive Sync", fontWeight = FontWeight.Bold, color = BlueDeep)
            Text("Not connected yet", fontSize = 12.sp, color = Color.DarkGray)
        }
        Button(onClick = { onOpen(Routes.CLOUD) }, colors = ButtonDefaults.buttonColors(containerColor = BlueMid)) {
            Text("Sync Now")
        }
    }
}

@Composable
private fun EditCompanyDialog(current: CompanyInfo, onDismiss: () -> Unit, onSave: (CompanyInfo) -> Unit) {
    var name by remember { mutableStateOf(current.name) }
    var phone by remember { mutableStateOf(current.phone) }
    var address by remember { mutableStateOf(current.address) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Company Info") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Company name") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Address") })
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(CompanyInfo(1, name.trim(), phone.trim(), address.trim())) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
