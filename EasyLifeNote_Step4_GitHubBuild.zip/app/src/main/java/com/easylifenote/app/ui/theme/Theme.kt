package com.easylifenote.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BlueDeep = Color(0xFF0B2A9E)
val BlueMid = Color(0xFF1B55E0)
val BlueSky = Color(0xFF4A9BFF)
val Gold = Color(0xFFFFD21F)
val GreenA = Color(0xFF3BBE2E)
val GreenB = Color(0xFF0E8F3A)
val PurpleA = Color(0xFFB04BE8)
val PurpleB = Color(0xFF6A1FC9)
val CardWhite = Color(0xFFF4F8FF)

private val Scheme = lightColorScheme(
    primary = BlueMid,
    secondary = BlueSky,
    background = Color.White,
    surface = Color.White
)

@Composable
fun EasyLifeNoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
