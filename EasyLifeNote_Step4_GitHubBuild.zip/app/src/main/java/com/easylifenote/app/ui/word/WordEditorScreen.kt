package com.easylifenote.app.ui.word

import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignJustify
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easylifenote.app.export.WordHtml
import com.easylifenote.app.export.WordPrinter
import com.easylifenote.app.ui.common.GradientScreen
import com.easylifenote.app.ui.theme.BlueDeep
import com.easylifenote.app.ui.theme.BlueMid
import com.easylifenote.app.ui.theme.CardWhite

private val Red = Color(0xFFD01C1C)

/** Holds the editor once the WebView exists (plain holder, not state). */
private class EditorHolder {
    var editor: WebEditor? = null
}

private val FONTS = listOf(
    "Arial" to "Arial, sans-serif",
    "Times New Roman" to "Times New Roman, serif",
    "Courier New" to "Courier New, monospace",
    "Georgia" to "Georgia, serif",
    "Verdana" to "Verdana, sans-serif",
    "Tahoma" to "Tahoma, sans-serif"
)
private val SIZES = listOf(10, 12, 14, 16, 18, 20, 24, 28, 32, 36)
private val TEXT_COLORS = listOf(
    "#000000", "#444444", "#888888", "#D01C1C", "#F57C00", "#FFC107",
    "#2E7D32", "#00897B", "#1B55E0", "#0B2A9E", "#7B1FA2", "#E91E63"
)
private val HILITE_COLORS = listOf(
    "#FFFF00", "#B9F6CA", "#80DEEA", "#F8BBD0", "#FFCC80", "#E0E0E0", "transparent"
)

@Composable
fun WordEditorScreen(onBack: () -> Unit, vm: WordEditorViewModel = viewModel()) {
    val context = LocalContext.current
    val holder = remember { EditorHolder() }
    var showTable by remember { mutableStateOf(false) }
    var showTextColor by remember { mutableStateOf(false) }
    var showHilite by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var pendingDoc by remember { mutableStateOf<String?>(null) }

    fun toast(msg: String, long: Boolean = false) =
        Toast.makeText(context, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

    fun safeName(): String =
        vm.title.trim().replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifEmpty { "Document" }

    fun saveAndExit() {
        val ed = holder.editor
        if (ed == null) {
            onBack()
            return
        }
        ed.getHtml { html ->
            vm.save(html) { err -> if (err == null) onBack() else toast(err) }
        }
    }

    BackHandler { saveAndExit() }

    // Auto-save: when the app is paused, and every 10 seconds while editing.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                holder.editor?.getHtml { html -> vm.save(html) { } }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(vm.loading) {
        if (!vm.loading) {
            while (true) {
                kotlinx.coroutines.delay(10_000)
                holder.editor?.getHtml { html -> vm.save(html) { } }
            }
        }
    }

    val docLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/msword")
    ) { uri: Uri? ->
        val html = pendingDoc
        pendingDoc = null
        if (uri != null && html != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(WordHtml.docPage(vm.title.ifBlank { "Document" }, html).toByteArray(Charsets.UTF_8))
                }
                toast("Word file saved")
            } catch (e: Exception) {
                toast("Could not save file: ${e.message}")
            }
        }
    }

    GradientScreen {
        Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 10.dp)) {
            // ---------------- header ----------------
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { saveAndExit() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                }
                BasicTextField(
                    value = vm.title,
                    onValueChange = { vm.title = it },
                    singleLine = true,
                    textStyle = TextStyle(color = BlueDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp),
                    modifier = Modifier.weight(1f).height(40.dp).background(Color.White, RoundedCornerShape(12.dp)),
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxSize().padding(horizontal = 12.dp), contentAlignment = Alignment.CenterStart) {
                            if (vm.title.isEmpty()) Text("Document title", color = Color.Gray, fontSize = 16.sp)
                            inner()
                        }
                    }
                )
                IconButton(onClick = {
                    val ed = holder.editor
                    if (ed == null) toast("Editor is still loading.")
                    else ed.getHtml { html ->
                        vm.save(html) { err -> toast(err ?: "Document saved") }
                    }
                }) { Icon(Icons.Default.Save, "Save", tint = Color.White) }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "More", tint = Color.White) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Print") }, onClick = {
                            menuOpen = false
                            holder.editor?.getHtml { html -> WordPrinter.print(context, vm.title.ifBlank { "Document" }, html) }
                        })
                        DropdownMenuItem(text = { Text("Export as PDF") }, onClick = {
                            menuOpen = false
                            holder.editor?.getHtml { html ->
                                toast("In the print screen, choose \"Save as PDF\" as the printer.", long = true)
                                WordPrinter.print(context, vm.title.ifBlank { "Document" }, html)
                            }
                        })
                        DropdownMenuItem(text = { Text("Export as Word (.doc)") }, onClick = {
                            menuOpen = false
                            holder.editor?.getHtml { html ->
                                pendingDoc = html
                                docLauncher.launch("${safeName()}.doc")
                            }
                        })
                        if (vm.isSaved) {
                            DropdownMenuItem(text = { Text("Delete document", color = Red) }, onClick = {
                                menuOpen = false
                                showDelete = true
                            })
                        }
                    }
                }
            }

            if (vm.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White)
                }
            } else {
                // ---------------- toolbar ----------------
                Row(
                    Modifier.fillMaxWidth()
                        .background(CardWhite, RoundedCornerShape(14.dp))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val ed = { holder.editor }
                    ToolIcon(Icons.AutoMirrored.Filled.Undo, "Undo") { ed()?.undo() }
                    ToolIcon(Icons.AutoMirrored.Filled.Redo, "Redo") { ed()?.redo() }
                    Divider()
                    ToolButton({ ed()?.bold() }) { Text("B", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = BlueDeep) }
                    ToolButton({ ed()?.italic() }) { Text("I", fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BlueDeep) }
                    ToolButton({ ed()?.underline() }) { Text("U", textDecoration = TextDecoration.Underline, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = BlueDeep) }
                    Divider()
                    MenuButton("Font") { close ->
                        FONTS.forEach { (label, css) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { close(); ed()?.fontName(css) })
                        }
                    }
                    MenuButton("Size") { close ->
                        SIZES.forEach { px ->
                            DropdownMenuItem(text = { Text("$px") }, onClick = { close(); ed()?.fontSize(px) })
                        }
                    }
                    ToolIcon(Icons.Default.FormatColorText, "Text color") { showTextColor = true }
                    ToolIcon(Icons.Default.FormatColorFill, "Highlight") { showHilite = true }
                    Divider()
                    ToolIcon(Icons.Default.FormatAlignLeft, "Align left") { ed()?.alignLeft() }
                    ToolIcon(Icons.Default.FormatAlignCenter, "Align center") { ed()?.alignCenter() }
                    ToolIcon(Icons.Default.FormatAlignRight, "Align right") { ed()?.alignRight() }
                    ToolIcon(Icons.Default.FormatAlignJustify, "Justify") { ed()?.alignJustify() }
                    Divider()
                    ToolIcon(Icons.Default.FormatListBulleted, "Bullet list") { ed()?.bullets() }
                    ToolIcon(Icons.Default.FormatListNumbered, "Numbered list") { ed()?.numbering() }
                    Divider()
                    MenuButton("Table") { close ->
                        val noCell = { r: String -> if (r == "nocell") toast("Place the cursor inside a table cell first.") }
                        DropdownMenuItem(text = { Text("Insert table...") }, onClick = { close(); showTable = true })
                        DropdownMenuItem(text = { Text("Add row below") }, onClick = { close(); ed()?.tableOp("rowBelow", noCell) })
                        DropdownMenuItem(text = { Text("Add row above") }, onClick = { close(); ed()?.tableOp("rowAbove", noCell) })
                        DropdownMenuItem(text = { Text("Add column right") }, onClick = { close(); ed()?.tableOp("colRight", noCell) })
                        DropdownMenuItem(text = { Text("Add column left") }, onClick = { close(); ed()?.tableOp("colLeft", noCell) })
                        DropdownMenuItem(text = { Text("Delete row") }, onClick = { close(); ed()?.tableOp("delRow", noCell) })
                        DropdownMenuItem(text = { Text("Delete column") }, onClick = { close(); ed()?.tableOp("delCol", noCell) })
                        DropdownMenuItem(text = { Text("Delete table", color = Red) }, onClick = { close(); ed()?.tableOp("delTable", noCell) })
                    }
                    Divider()
                    ToolIcon(Icons.Default.ContentCut, "Cut") {
                        ed()?.copy(context, cut = true) { ok -> if (!ok) toast("Select some text first.") }
                    }
                    ToolIcon(Icons.Default.ContentCopy, "Copy") {
                        ed()?.copy(context, cut = false) { ok -> toast(if (ok) "Copied" else "Select some text first.") }
                    }
                    ToolIcon(Icons.Default.ContentPaste, "Paste") {
                        val ok = ed()?.paste(context) ?: false
                        if (!ok) toast("Nothing to paste.")
                    }
                    ToolIcon(Icons.Default.SelectAll, "Select all") { ed()?.selectAll() }
                }

                // ---------------- editing page ----------------
                Box(
                    Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp, bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp)).background(Color.White)
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.javaScriptEnabled = true
                                settings.allowFileAccess = false
                                settings.allowContentAccess = false
                                settings.setSupportZoom(false)
                                webViewClient = WebViewClient()
                                setBackgroundColor(android.graphics.Color.WHITE)
                                loadDataWithBaseURL(
                                    null, WordHtml.editorPage(vm.initialHtml), "text/html", "utf-8", null
                                )
                                holder.editor = WebEditor(this)
                            }
                        },
                        onRelease = { web ->
                            holder.editor = null
                            web.destroy()
                        }
                    )
                }
            }
        }
    }

    // ---------------- dialogs ----------------
    if (showTable) {
        TableDialog(
            onDismiss = { showTable = false },
            onInsert = { r, c -> holder.editor?.insertTable(r, c); showTable = false }
        )
    }
    if (showTextColor) {
        ColorDialog("Text color", TEXT_COLORS, onDismiss = { showTextColor = false }) {
            holder.editor?.textColor(it); showTextColor = false
        }
    }
    if (showHilite) {
        ColorDialog("Highlight color", HILITE_COLORS, onDismiss = { showHilite = false }) {
            holder.editor?.highlight(it); showHilite = false
        }
    }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete document?") },
            text = { Text("This document will be deleted permanently.") },
            confirmButton = {
                TextButton(onClick = { showDelete = false; vm.deleteDocument { onBack() } }) {
                    Text("Delete", color = Red)
                }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- toolbar parts

@Composable
private fun ToolButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(42.dp), content = content)
}

@Composable
private fun ToolIcon(icon: ImageVector, description: String, onClick: () -> Unit) {
    ToolButton(onClick) { Icon(icon, contentDescription = description, tint = BlueMid) }
}

@Composable
private fun Divider() {
    Spacer(Modifier.width(4.dp))
    Box(Modifier.width(1.dp).height(24.dp).background(Color(0xFFB0C4EE)))
    Spacer(Modifier.width(4.dp))
}

/** A small text button that opens a drop-down menu. */
@Composable
private fun MenuButton(label: String, items: @Composable (close: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            Text("$label ▾", color = BlueDeep, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items { open = false }
        }
    }
}

// ---------------------------------------------------------------- dialogs

@Composable
private fun TableDialog(onDismiss: () -> Unit, onInsert: (Int, Int) -> Unit) {
    var rows by remember { mutableStateOf("3") }
    var cols by remember { mutableStateOf("3") }
    var error by remember { mutableStateOf<String?>(null) }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Insert table") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    rows, { if (it.all { c -> c.isDigit() } && it.length <= 2) rows = it },
                    label = { Text("Rows (1-50)") }, singleLine = true, keyboardOptions = numeric
                )
                OutlinedTextField(
                    cols, { if (it.all { c -> c.isDigit() } && it.length <= 2) cols = it },
                    label = { Text("Columns (1-10)") }, singleLine = true, keyboardOptions = numeric
                )
                error?.let { Text(it, color = Red, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = rows.toIntOrNull()
                val c = cols.toIntOrNull()
                if (r == null || c == null || r !in 1..50 || c !in 1..10) {
                    error = "Rows: 1-50, columns: 1-10."
                } else onInsert(r, c)
            }) { Text("Insert") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ColorDialog(title: String, colors: List<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                colors.chunked(6).forEach { rowColors ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowColors.forEach { hex ->
                            if (hex == "transparent") {
                                Box(
                                    Modifier.size(36.dp).clip(CircleShape).background(Color.White)
                                        .clickable { onPick(hex) },
                                    contentAlignment = Alignment.Center
                                ) { Text("None", fontSize = 10.sp, color = Red, fontWeight = FontWeight.Bold) }
                            } else {
                                Box(
                                    Modifier.size(36.dp).clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(hex)))
                                        .clickable { onPick(hex) }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
