EASY LIFE NOTE - BUILD SETUP
============================

1) OPEN IN ANDROID STUDIO (recommended - no wrapper jar needed)
   File > Open > select this folder > wait for "Gradle sync" to finish.
   Android Studio reads gradle/wrapper/gradle-wrapper.properties and downloads
   Gradle 8.9 by itself. Then press the green Run button.
   Requirements: Android Studio Koala or newer, JDK 17+ (bundled with Studio),
   internet on the first sync.

2) COMMAND-LINE BUILDS (./gradlew assembleDebug) need gradle-wrapper.jar
   The jar is a binary file that could not be generated where this project
   was written. Get it in ONE of these ways:

   A) Copy it from your own Android Studio project (every project created by
      Android Studio has it):
         <your project>/gradle/wrapper/gradle-wrapper.jar
      into this folder's gradle/wrapper/ directory.

   B) If Gradle is installed on your computer, run this once in this folder:
         gradle wrapper --gradle-version 8.9
      It creates gradle-wrapper.jar (and refreshes gradlew / gradlew.bat).

   Then:  ./gradlew assembleDebug      (Windows: gradlew.bat assembleDebug)
   The APK appears in app/build/outputs/apk/debug/.

3) FILE CHECKLIST
   settings.gradle.kts, build.gradle.kts, gradle.properties,
   gradle/wrapper/gradle-wrapper.properties, gradlew, gradlew.bat   (present)
   gradle/wrapper/gradle-wrapper.jar                                (you add: step 2)
