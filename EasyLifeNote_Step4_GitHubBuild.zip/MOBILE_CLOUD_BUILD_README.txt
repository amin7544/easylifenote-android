MOBILE CLOUD BUILD (GitHub Actions)

This project is configured for Gradle 8.9 in gradle/wrapper/gradle-wrapper.properties.
The ZIP does not contain gradle-wrapper.jar, so the included GitHub Actions workflow
uses the hosted runner's Gradle 8.9 installation directly and does not invoke ./gradlew.

To use: extract this ZIP, create a GitHub repository, upload the extracted project
contents (including the hidden .github folder), then open Actions and run
"Android Debug APK" using Run workflow. When it finishes, open the run, scroll to
Artifacts, and download EasyLifeNote-debug-apk.

This workflow has not been run here. A successful APK is only confirmed after
GitHub Actions completes successfully.
